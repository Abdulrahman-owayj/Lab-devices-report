// Lab Care — school lab device maintenance (Arabic / English).
// One Worker serves the pages + JSON API; one SQLite Durable Object ("main") holds labs, devices, requests, logs and photos.
//   /            students: report a problem, track a report, about the project
//   /d/<CODE>    QR on a device → report form for that device      /l/<CODE>  QR on a lab door → that lab's devices
//   /admin       maintenance team + admins (username + password)
//   /img/<id>    photo attached to a report (unguessable id)

export { Store } from './store.js';

const MAX_PHOTO = 1900 * 1024; // SQLite row limit is 2 MB

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const err = (message, status = 400) => json({ ok: false, error: message }, status);
const store = (env) => env.STORE.get(env.STORE.idFromName('main'));

export default {
  async fetch(request, env) {
    try {
      const res = await route(request, env);
      const out = new Response(res.body, res);
      out.headers.set('x-content-type-options', 'nosniff');
      out.headers.set('referrer-policy', 'strict-origin-when-cross-origin');
      return out;
    } catch (e) {
      return err('Server error: ' + (e.message || e), 500);
    }
  },
};

async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  let m;

  if ((m = path.match(/^\/img\/([a-f0-9]{32})$/)) && method === 'GET') {
    const buf = await store(env).getPhoto(m[1]);
    if (!buf) return new Response('Not found', { status: 404 });
    return new Response(buf, { headers: { 'content-type': 'image/jpeg', 'cache-control': 'private, max-age=31536000, immutable' } });
  }

  if (path.startsWith('/api/')) {
    const token = request.headers.get('x-token') || '';
    const ip = request.headers.get('cf-connecting-ip') || 'local';
    // student report: multipart form with an optional photo
    if (path === '/api/pub/report' && method === 'POST') {
      const form = await request.formData().catch(() => null);
      if (!form) return err('بيانات غير صالحة');
      const fields = {};
      for (const k of ['device_id', 'problem', 'description', 'reporter', 'grade']) fields[k] = form.get(k) || '';
      const photo = form.get('photo');
      let buf = null;
      if (photo && typeof photo !== 'string') {
        buf = await photo.arrayBuffer();
        if (buf.byteLength > MAX_PHOTO) return err('الصورة كبيرة جداً', 413);
      }
      const r = await store(env).report(fields, buf, ip);
      return json(r.data, r.status);
    }
    let body = null;
    if (method !== 'GET' && method !== 'HEAD') body = await request.json().catch(() => ({}));
    const r = await store(env).api(method, path.slice(4), body, Object.fromEntries(url.searchParams), token, ip, env.RECOVERY_KEY || '');
    return json(r.data, r.status);
  }

  // SPA entry points
  if (path === '/admin' || path === '/admin/' || /^\/[dl]\/[A-Za-z0-9-]{1,30}$/.test(path)) {
    return env.ASSETS.fetch(new Request(new URL('/', url), request));
  }
  return env.ASSETS.fetch(request);
}

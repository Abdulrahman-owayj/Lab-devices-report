// The single Durable Object: labs → devices → requests (student reports) → device log.
// Team members log in with username + password (PBKDF2). Error messages are Arabic; the client translates them.
import { DurableObject } from 'cloudflare:workers';

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)`,
  `CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE, name TEXT, role TEXT, salt TEXT, hash TEXT,
     active INTEGER DEFAULT 1, created_at INTEGER, last_login INTEGER)`,
  `CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT, created_at INTEGER, last_at INTEGER)`,
  `CREATE TABLE IF NOT EXISTS labs (id TEXT PRIMARY KEY, code TEXT UNIQUE, name TEXT, name_en TEXT, location TEXT, notes TEXT,
     dev_seq INTEGER DEFAULT 0, created_at INTEGER)`,
  `CREATE TABLE IF NOT EXISTS devices (id TEXT PRIMARY KEY, lab_id TEXT, code TEXT UNIQUE, name TEXT, type TEXT, brand TEXT, model TEXT,
     serial TEXT, status TEXT DEFAULT 'ok', damage TEXT, damage_note TEXT, last_maint_at INTEGER, last_maint_by TEXT, notes TEXT,
     created_at INTEGER, updated_at INTEGER)`,
  `CREATE INDEX IF NOT EXISTS devices_lab ON devices(lab_id)`,
  `CREATE TABLE IF NOT EXISTS requests (id TEXT PRIMARY KEY, no INTEGER UNIQUE, device_id TEXT, lab_id TEXT, problem TEXT, description TEXT,
     reporter TEXT, grade TEXT, photo_id TEXT, status TEXT DEFAULT 'new', assigned_id TEXT, assigned_name TEXT, resolution TEXT,
     created_at INTEGER, updated_at INTEGER, closed_at INTEGER, closed_by TEXT)`,
  `CREATE INDEX IF NOT EXISTS requests_dev ON requests(device_id, status)`,
  `CREATE INDEX IF NOT EXISTS requests_st ON requests(status, created_at)`,
  `CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT, request_no INTEGER, ts INTEGER, user TEXT,
     kind TEXT, status TEXT, damage TEXT, note TEXT)`,
  `CREATE INDEX IF NOT EXISTS logs_dev ON logs(device_id, id)`,
  `CREATE TABLE IF NOT EXISTS photos (id TEXT PRIMARY KEY, data BLOB, created_at INTEGER)`,
];

const STATUSES = ['ok', 'needs_fix', 'in_repair', 'out'];
const DAMAGES = ['power', 'screen', 'input', 'software', 'network', 'sound', 'slow', 'physical', 'other'];
const TYPES = ['pc', 'laptop', 'projector', 'board', 'printer', 'microscope', 'screen', 'network', 'other'];
const OPEN = "('new','progress')";
const USER_RE = /^[a-z0-9._-]{3,30}$/;
const CODE_RE = /^[A-Z0-9]{1,8}$/;
const DEV_CODE_RE = /^[A-Z0-9]{1,8}(-[A-Z0-9]{1,8}){0,2}$/;

class HttpErr extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }
const bad = (msg, status = 400) => { throw new HttpErr(msg, status); };
const now = () => Date.now();
const uid = () => crypto.randomUUID();
const hex = (n) => [...crypto.getRandomValues(new Uint8Array(n))].map((b) => b.toString(16).padStart(2, '0')).join('');
const str = (v, max = 300) => (v == null ? null : String(v).trim().slice(0, max) || null);
const int = (v, d = 0) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
const normCode = (v) => String(v || '').trim().toUpperCase().replace(/\s+/g, '').replace(/[_/.]/g, '-');

async function hashPw(password, saltHex) {
  const enc = new TextEncoder();
  const salt = Uint8Array.from(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, key, 256);
  return [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function sameStr(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

export class Store extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.sql = ctx.storage.sql;
    this.fails = new Map(); // login throttle: username → {n, until}
    this.reports = new Map(); // student report throttle: ip → [timestamps]
    ctx.blockConcurrencyWhile(async () => {
      for (const s of SCHEMA) this.sql.exec(s);
      if (!this.one('SELECT id FROM users LIMIT 1')) {
        // first run: admin / 2020 — the admin changes it from the menu
        const salt = hex(16);
        this.sql.exec('INSERT INTO users (id, username, name, role, salt, hash, created_at) VALUES (?,?,?,?,?,?,?)',
          uid(), 'admin', 'مدير النظام', 'admin', salt, await hashPw('2020', salt), now());
      }
    });
  }

  q(sql, ...a) { return this.sql.exec(sql, ...a).toArray(); }
  one(sql, ...a) { return this.sql.exec(sql, ...a).toArray()[0] || null; }
  meta(k, d = null) { const r = this.one('SELECT v FROM meta WHERE k=?', k); return r ? JSON.parse(r.v) : d; }
  setMeta(k, v) { this.sql.exec('INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', k, JSON.stringify(v)); }

  log(device_id, user, kind, { status = null, damage = null, note = null, request_no = null } = {}) {
    this.sql.exec('INSERT INTO logs (device_id, request_no, ts, user, kind, status, damage, note) VALUES (?,?,?,?,?,?,?,?)',
      device_id, request_no, now(), user, kind, status, damage, note);
  }

  async getPhoto(id) {
    const r = this.one('SELECT data FROM photos WHERE id=?', id);
    return r ? r.data : null;
  }

  // ---------- student report (public)
  async report(f, photo, ip) {
    try {
      const t = now();
      const recent = (this.reports.get(ip) || []).filter((x) => t - x < 10 * 60e3);
      if (recent.length >= 8) bad('بلاغات كثيرة — حاول بعد قليل', 429);
      const dev = this.one('SELECT * FROM devices WHERE id=?', String(f.device_id || ''));
      if (!dev) bad('الجهاز غير موجود', 404);
      const problem = DAMAGES.includes(f.problem) ? f.problem : bad('اختر نوع المشكلة');
      const description = str(f.description, 1000);
      if (problem === 'other' && !description) bad('اكتب وصف المشكلة');
      let photo_id = null;
      if (photo && photo.byteLength > 0) {
        photo_id = hex(16);
        this.sql.exec('INSERT INTO photos (id, data, created_at) VALUES (?,?,?)', photo_id, photo, t);
      }
      const no = (this.one('SELECT MAX(no) AS n FROM requests')?.n || 1000) + 1;
      this.sql.exec(`INSERT INTO requests (id, no, device_id, lab_id, problem, description, reporter, grade, photo_id, status, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,'new',?,?)`, uid(), no, dev.id, dev.lab_id, problem, description, str(f.reporter, 60), str(f.grade, 30), photo_id, t, t);
      const who = str(f.reporter, 60) || 'طالب';
      this.log(dev.id, who, 'report', { damage: problem, note: description, request_no: no });
      if (dev.status === 'ok') {
        this.sql.exec("UPDATE devices SET status='needs_fix', damage=?, damage_note=?, updated_at=? WHERE id=?", problem, description, t, dev.id);
        this.log(dev.id, who, 'status', { status: 'needs_fix', damage: problem, request_no: no });
      }
      recent.push(t); this.reports.set(ip, recent);
      return { status: 200, data: { ok: true, no } };
    } catch (e) {
      if (e instanceof HttpErr) return { status: e.status, data: { ok: false, error: e.message } };
      throw e;
    }
  }

  // ---------- JSON API
  async api(method, path, body, query, token, ip, recoveryKey) {
    try {
      const data = await this.route(method, path, body || {}, query || {}, token, recoveryKey);
      return { status: 200, data: { ok: true, ...data } };
    } catch (e) {
      if (e instanceof HttpErr) return { status: e.status, data: { ok: false, error: e.message } };
      throw e;
    }
  }

  auth(token, admin) {
    const s = token && this.one('SELECT s.token, s.last_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?', token);
    if (!s || !s.active) bad('سجّل الدخول', 401);
    if (now() - s.last_at > 60e3) this.sql.exec('UPDATE sessions SET last_at=? WHERE token=?', now(), token);
    if (admin && s.role !== 'admin') bad('للمدير فقط', 403);
    return s;
  }

  async route(method, path, b, q, token, recoveryKey) {
    let m;
    const M = (re, meth) => method === meth && (m = path.match(re));

    // ----- public
    if (M(/^\/pub\/labs$/, 'GET')) {
      const labs = this.q('SELECT id, code, name, name_en, location FROM labs ORDER BY code');
      const devices = this.q(`SELECT d.id, d.lab_id, d.code, d.name, d.type, d.status,
        (SELECT COUNT(*) FROM requests r WHERE r.device_id=d.id AND r.status IN ${OPEN}) AS open_reqs FROM devices d ORDER BY d.code`);
      return { labs, devices, about: this.about() };
    }
    if (M(/^\/pub\/track\/(\d{1,7})$/, 'GET')) {
      const r = this.one(`SELECT r.no, r.problem, r.status, r.created_at, r.updated_at, r.closed_at, r.resolution,
        d.code AS device_code, d.name AS device_name, l.name AS lab_name, l.name_en AS lab_name_en
        FROM requests r LEFT JOIN devices d ON d.id=r.device_id LEFT JOIN labs l ON l.id=r.lab_id WHERE r.no=?`, int(m[1]));
      if (!r) bad('لا يوجد بلاغ بهذا الرقم', 404);
      return { request: r };
    }
    if (M(/^\/pub\/about$/, 'GET')) return { about: this.about() };

    // ----- auth
    if (M(/^\/login$/, 'POST')) {
      const username = String(b.username || '').trim().toLowerCase();
      const f = this.fails.get(username);
      if (f && f.until > now()) bad('محاولات كثيرة — انتظر 5 دقائق', 429);
      const u = this.one('SELECT * FROM users WHERE username=?', username);
      if (!u || !u.active || !sameStr(await hashPw(String(b.password || ''), u.salt), u.hash)) {
        const n = (f && f.until <= now() && f.n >= 8 ? 0 : f?.n || 0) + 1;
        this.fails.set(username, { n, until: n >= 8 ? now() + 5 * 60e3 : 0 });
        bad('اسم المستخدم أو كلمة المرور غير صحيحة', 401);
      }
      this.fails.delete(username);
      const tok = hex(24);
      this.sql.exec('INSERT INTO sessions (token, user_id, created_at, last_at) VALUES (?,?,?,?)', tok, u.id, now(), now());
      this.sql.exec('UPDATE users SET last_login=? WHERE id=?', now(), u.id);
      this.sql.exec('DELETE FROM sessions WHERE last_at < ?', now() - 60 * 864e5);
      return { token: tok, user: this.pubUser(u) };
    }
    if (M(/^\/logout$/, 'POST')) { this.sql.exec('DELETE FROM sessions WHERE token=?', token); return {}; }
    if (M(/^\/recover$/, 'POST')) {
      if (!recoveryKey) bad('استعادة كلمة المرور غير مفعّلة — اطلب من المدير إعادة تعيينها');
      const f = this.fails.get('#recover');
      if (f && f.until > now()) bad('محاولات كثيرة — انتظر 5 دقائق', 429);
      if (!sameStr(String(b.key || '').trim(), recoveryKey)) {
        const n = (f?.n || 0) + 1;
        this.fails.set('#recover', { n, until: n >= 5 ? now() + 5 * 60e3 : 0 });
        bad('رمز الاستعادة غير صحيح', 401);
      }
      this.fails.delete('#recover');
      const u = this.one('SELECT * FROM users WHERE username=?', String(b.username || '').trim().toLowerCase());
      if (!u) bad('اسم المستخدم غير موجود', 404);
      await this.setPassword(u.id, b.password);
      this.sql.exec('UPDATE users SET active=1 WHERE id=?', u.id);
      return {};
    }

    const me = this.auth(token, false);
    if (M(/^\/me$/, 'GET')) return { user: this.pubUser(me) };
    if (M(/^\/me\/password$/, 'POST')) {
      if (!sameStr(await hashPw(String(b.current || ''), me.salt), me.hash)) bad('كلمة المرور الحالية غير صحيحة');
      await this.setPassword(me.id, b.password);
      this.sql.exec('DELETE FROM sessions WHERE user_id=? AND token<>?', me.id, token);
      return {};
    }

    // ----- dashboard
    if (M(/^\/dash$/, 'GET')) {
      const st = Object.fromEntries(STATUSES.map((s) => [s, 0]));
      for (const r of this.q('SELECT status, COUNT(*) AS n FROM devices GROUP BY status')) st[r.status] = r.n;
      const req = Object.fromEntries(['new', 'progress', 'done', 'closed'].map((s) => [s, 0]));
      for (const r of this.q('SELECT status, COUNT(*) AS n FROM requests GROUP BY status')) req[r.status] = r.n;
      const labs = this.q(`SELECT l.id, l.code, l.name, l.name_en, COUNT(d.id) AS total,
        SUM(d.status='ok') AS ok, SUM(d.status='needs_fix') AS needs_fix, SUM(d.status='in_repair') AS in_repair, SUM(d.status='out') AS out
        FROM labs l LEFT JOIN devices d ON d.lab_id=l.id GROUP BY l.id ORDER BY l.code`);
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const fixedWeek = this.one("SELECT COUNT(*) AS n FROM requests WHERE status='done' AND closed_at > ?", now() - 7 * 864e5).n;
      return { devices: st, requests: req, labs, fixed_week: fixedWeek, recent: this.reqList({ status: 'open' }).slice(0, 6) };
    }
    if (M(/^\/count$/, 'GET')) return { new: this.one("SELECT COUNT(*) AS n FROM requests WHERE status='new'").n };

    // ----- requests
    if (M(/^\/requests$/, 'GET')) return { requests: this.reqList(q) };
    if (M(/^\/requests\/(\d{1,7})$/, 'GET')) {
      const r = this.reqList({ no: m[1] })[0] || bad('لا يوجد بلاغ بهذا الرقم', 404);
      const others = this.q(`SELECT no, problem, status, created_at FROM requests WHERE device_id=? AND no<>? ORDER BY no DESC LIMIT 10`, r.device_id, r.no);
      const log = this.q('SELECT * FROM logs WHERE request_no=? ORDER BY id', r.no);
      return { request: r, others, log };
    }
    if (M(/^\/requests\/(\d{1,7})\/action$/, 'POST')) return this.reqAction(me, int(m[1]), b);

    // ----- labs + devices (everyone on the team reads; admins change the structure)
    if (M(/^\/labs$/, 'GET')) {
      return { labs: this.q(`SELECT l.*, COUNT(d.id) AS total, SUM(d.status='ok') AS ok, SUM(d.status='needs_fix') AS needs_fix,
        SUM(d.status='in_repair') AS in_repair, SUM(d.status='out') AS out FROM labs l LEFT JOIN devices d ON d.lab_id=l.id GROUP BY l.id ORDER BY l.code`) };
    }
    if (M(/^\/labs\/([a-z0-9-]{36})$/, 'GET')) {
      const lab = this.one('SELECT * FROM labs WHERE id=?', m[1]) || bad('المعمل غير موجود', 404);
      const devices = this.q(`SELECT d.*, (SELECT COUNT(*) FROM requests r WHERE r.device_id=d.id AND r.status IN ${OPEN}) AS open_reqs
        FROM devices d WHERE d.lab_id=? ORDER BY d.code`, lab.id);
      return { lab, devices };
    }
    if (M(/^\/labs$/, 'POST')) {
      this.auth(token, true);
      const lab = this.labFields(b, null);
      const id = uid();
      this.sql.exec('INSERT INTO labs (id, code, name, name_en, location, notes, created_at) VALUES (?,?,?,?,?,?,?)',
        id, lab.code, lab.name, lab.name_en, lab.location, lab.notes, now());
      return { id };
    }
    if (M(/^\/labs\/([a-z0-9-]{36})$/, 'PATCH')) {
      this.auth(token, true);
      const old = this.one('SELECT * FROM labs WHERE id=?', m[1]) || bad('المعمل غير موجود', 404);
      const lab = this.labFields({ ...old, ...b }, old.id);
      this.sql.exec('UPDATE labs SET code=?, name=?, name_en=?, location=?, notes=? WHERE id=?', lab.code, lab.name, lab.name_en, lab.location, lab.notes, old.id);
      return {};
    }
    if (M(/^\/labs\/([a-z0-9-]{36})$/, 'DELETE')) {
      this.auth(token, true);
      const ids = this.q('SELECT id FROM devices WHERE lab_id=?', m[1]).map((r) => r.id);
      for (const id of ids) this.deleteDevice(id);
      this.sql.exec('DELETE FROM labs WHERE id=?', m[1]);
      return {};
    }
    if (M(/^\/labs\/([a-z0-9-]{36})\/devices$/, 'POST')) {
      this.auth(token, true);
      const lab = this.one('SELECT * FROM labs WHERE id=?', m[1]) || bad('المعمل غير موجود', 404);
      const type = TYPES.includes(b.type) ? b.type : 'other';
      const count = Math.min(Math.max(int(b.count, 1), 1), 60);
      const base = str(b.name, 60);
      const fields = { brand: str(b.brand, 60), model: str(b.model, 60), serial: count === 1 ? str(b.serial, 60) : null, notes: str(b.notes, 500) };
      let seq = lab.dev_seq;
      const made = [];
      for (let i = 0; i < count; i++) {
        let code;
        do { seq++; code = `${lab.code}-${String(seq).padStart(2, '0')}`; } while (this.one('SELECT id FROM devices WHERE code=?', code));
        const name = count === 1 ? (base || code) : `${base || ''} ${i + 1}`.trim() || code;
        const id = uid();
        this.sql.exec(`INSERT INTO devices (id, lab_id, code, name, type, brand, model, serial, status, notes, created_at, updated_at)
          VALUES (?,?,?,?,?,?,?,?,'ok',?,?,?)`, id, lab.id, code, name, type, fields.brand, fields.model, fields.serial, fields.notes, now(), now());
        this.log(id, me.name, 'created', { status: 'ok' });
        made.push(id);
      }
      this.sql.exec('UPDATE labs SET dev_seq=? WHERE id=?', seq, lab.id);
      return { ids: made };
    }
    if (M(/^\/devices\/([a-z0-9-]{36})$/, 'GET')) {
      const device = this.one(`SELECT d.*, l.name AS lab_name, l.name_en AS lab_name_en, l.code AS lab_code FROM devices d
        LEFT JOIN labs l ON l.id=d.lab_id WHERE d.id=?`, m[1]) || bad('الجهاز غير موجود', 404);
      const log = this.q('SELECT * FROM logs WHERE device_id=? ORDER BY id DESC LIMIT 300', device.id);
      const requests = this.q('SELECT no, problem, description, status, resolution, created_at, closed_at, closed_by, assigned_name FROM requests WHERE device_id=? ORDER BY no DESC', device.id);
      return { device, log, requests };
    }
    if (M(/^\/devices\/([a-z0-9-]{36})$/, 'PATCH')) {
      this.auth(token, true);
      const d = this.one('SELECT * FROM devices WHERE id=?', m[1]) || bad('الجهاز غير موجود', 404);
      const code = b.code != null ? normCode(b.code) : d.code;
      if (!DEV_CODE_RE.test(code)) bad('رمز الجهاز غير صالح');
      if (code !== d.code && this.one('SELECT id FROM devices WHERE code=?', code)) bad('الرمز مستخدم لجهاز آخر');
      const lab_id = b.lab_id && this.one('SELECT id FROM labs WHERE id=?', b.lab_id) ? b.lab_id : d.lab_id;
      const pick = (k, max) => (k in b ? str(b[k], max) : d[k]);
      this.sql.exec('UPDATE devices SET code=?, lab_id=?, name=?, type=?, brand=?, model=?, serial=?, notes=?, updated_at=? WHERE id=?',
        code, lab_id, pick('name', 60) || code, TYPES.includes(b.type) ? b.type : d.type, pick('brand', 60), pick('model', 60), pick('serial', 60), pick('notes', 500), now(), d.id);
      if (lab_id !== d.lab_id) this.sql.exec('UPDATE requests SET lab_id=? WHERE device_id=?', lab_id, d.id);
      this.log(d.id, me.name, 'edit', { note: lab_id !== d.lab_id ? 'نقل إلى معمل آخر' : null });
      return {};
    }
    if (M(/^\/devices\/([a-z0-9-]{36})$/, 'DELETE')) { this.auth(token, true); this.deleteDevice(m[1]); return {}; }

    // maintenance team actions on a device
    if (M(/^\/devices\/([a-z0-9-]{36})\/status$/, 'POST')) {
      const d = this.one('SELECT * FROM devices WHERE id=?', m[1]) || bad('الجهاز غير موجود', 404);
      const status = STATUSES.includes(b.status) ? b.status : bad('اختر الحالة');
      const damage = status === 'ok' ? null : DAMAGES.includes(b.damage) ? b.damage : status === 'needs_fix' ? bad('اختر نوع العطل') : d.damage;
      const note = str(b.note, 1000);
      const dnote = status === 'ok' ? null : note || (damage === d.damage ? d.damage_note : null);
      this.sql.exec('UPDATE devices SET status=?, damage=?, damage_note=?, updated_at=? WHERE id=?', status, damage, dnote, now(), d.id);
      this.log(d.id, me.name, 'status', { status, damage, note });
      return {};
    }
    if (M(/^\/devices\/([a-z0-9-]{36})\/maint$/, 'POST')) {
      const d = this.one('SELECT * FROM devices WHERE id=?', m[1]) || bad('الجهاز غير موجود', 404);
      const note = str(b.note, 1000) || bad('اكتب ما تم عمله');
      const status = STATUSES.includes(b.status) ? b.status : 'ok';
      const damage = status === 'ok' ? null : d.damage;
      this.sql.exec('UPDATE devices SET status=?, damage=?, damage_note=?, last_maint_at=?, last_maint_by=?, updated_at=? WHERE id=?',
        status, damage, status === 'ok' ? null : d.damage_note, now(), me.name, now(), d.id);
      this.log(d.id, me.name, 'maint', { status, damage, note });
      if (status === 'ok' && b.close_reqs) {
        for (const r of this.q(`SELECT no FROM requests WHERE device_id=? AND status IN ${OPEN}`, d.id)) {
          this.sql.exec("UPDATE requests SET status='done', resolution=?, closed_at=?, closed_by=?, updated_at=? WHERE no=?", note, now(), me.name, now(), r.no);
          this.log(d.id, me.name, 'req_done', { note, request_no: r.no });
        }
      }
      return {};
    }
    if (M(/^\/devices\/([a-z0-9-]{36})\/note$/, 'POST')) {
      const d = this.one('SELECT id FROM devices WHERE id=?', m[1]) || bad('الجهاز غير موجود', 404);
      this.log(d.id, me.name, 'note', { note: str(b.note, 1000) || bad('اكتب الملاحظة') });
      return {};
    }

    // ----- users (admin)
    if (M(/^\/users$/, 'GET')) {
      this.auth(token, true);
      return { users: this.q('SELECT id, username, name, role, active, created_at, last_login FROM users ORDER BY role, name') };
    }
    if (M(/^\/users$/, 'POST')) {
      this.auth(token, true);
      const username = String(b.username || '').trim().toLowerCase();
      if (!USER_RE.test(username)) bad('اسم المستخدم: 3 أحرف إنجليزية أو أرقام على الأقل');
      if (this.one('SELECT id FROM users WHERE username=?', username)) bad('اسم المستخدم موجود');
      const id = uid(), salt = hex(16);
      this.checkPw(b.password);
      this.sql.exec('INSERT INTO users (id, username, name, role, salt, hash, created_at) VALUES (?,?,?,?,?,?,?)',
        id, username, str(b.name, 60) || username, b.role === 'admin' ? 'admin' : 'tech', salt, await hashPw(String(b.password), salt), now());
      return { id };
    }
    if (M(/^\/users\/([a-z0-9-]{36})$/, 'PATCH')) {
      const admin = this.auth(token, true);
      const u = this.one('SELECT * FROM users WHERE id=?', m[1]) || bad('المستخدم غير موجود', 404);
      const role = b.role ? (b.role === 'admin' ? 'admin' : 'tech') : u.role;
      const active = b.active != null ? (b.active ? 1 : 0) : u.active;
      if (u.role === 'admin' && (role !== 'admin' || !active) && this.one("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND active=1").n <= 1) bad('يجب أن يبقى مدير واحد على الأقل');
      if (u.id === admin.id && !active) bad('لا يمكنك إيقاف حسابك');
      let username = u.username;
      if (b.username != null) {
        username = String(b.username).trim().toLowerCase();
        if (!USER_RE.test(username)) bad('اسم المستخدم: 3 أحرف إنجليزية أو أرقام على الأقل');
        if (username !== u.username && this.one('SELECT id FROM users WHERE username=?', username)) bad('اسم المستخدم موجود');
      }
      this.sql.exec('UPDATE users SET username=?, name=?, role=?, active=? WHERE id=?', username, b.name != null ? str(b.name, 60) || username : u.name, role, active, u.id);
      if (b.password) { await this.setPassword(u.id, b.password); if (u.id !== admin.id) this.sql.exec('DELETE FROM sessions WHERE user_id=?', u.id); }
      if (!active) this.sql.exec('DELETE FROM sessions WHERE user_id=?', u.id);
      return {};
    }
    if (M(/^\/users\/([a-z0-9-]{36})$/, 'DELETE')) {
      const admin = this.auth(token, true);
      const u = this.one('SELECT * FROM users WHERE id=?', m[1]) || bad('المستخدم غير موجود', 404);
      if (u.id === admin.id) bad('لا يمكنك حذف حسابك');
      if (u.role === 'admin' && this.one("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND active=1").n <= 1) bad('يجب أن يبقى مدير واحد على الأقل');
      this.sql.exec('DELETE FROM sessions WHERE user_id=?', u.id);
      this.sql.exec('DELETE FROM users WHERE id=?', u.id);
      return {};
    }

    // ----- about the project (admin edits, everyone reads)
    if (M(/^\/about$/, 'PUT')) {
      this.auth(token, true);
      const students = (Array.isArray(b.students) ? b.students : []).slice(0, 60)
        .map((s) => ({ name: str(s?.name, 80), role: str(s?.role, 80) })).filter((s) => s.name);
      this.setMeta('about', {
        title: str(b.title, 120), title_en: str(b.title_en, 120), school: str(b.school, 120), school_en: str(b.school_en, 120),
        supervisor: str(b.supervisor, 120), year: str(b.year, 30), description: str(b.description, 2000), description_en: str(b.description_en, 2000), students,
      });
      return {};
    }

    // ----- export (CSV is built in the browser)
    if (M(/^\/export$/, 'GET')) {
      return {
        devices: this.q(`SELECT d.*, l.code AS lab_code, l.name AS lab_name FROM devices d LEFT JOIN labs l ON l.id=d.lab_id ORDER BY d.code`),
        requests: this.reqList({ status: 'all', limit: 100000 }),
        logs: this.q(`SELECT g.*, d.code AS device_code FROM logs g LEFT JOIN devices d ON d.id=g.device_id ORDER BY g.id`),
      };
    }

    bad('غير موجود', 404);
  }

  about() {
    return this.meta('about', { title: null, school: null, supervisor: null, year: null, description: null, students: [] });
  }
  pubUser(u) { return { id: u.id, username: u.username, name: u.name, role: u.role }; }
  checkPw(p) { if (String(p || '').length < 4) bad('كلمة المرور 4 أحرف على الأقل'); }
  async setPassword(id, p) {
    this.checkPw(p);
    const salt = hex(16);
    this.sql.exec('UPDATE users SET salt=?, hash=? WHERE id=?', salt, await hashPw(String(p), salt), id);
  }
  labFields(b, id) {
    const code = normCode(b.code);
    if (!CODE_RE.test(code)) bad('رمز المعمل: حروف إنجليزية أو أرقام (حتى 8)');
    const dup = this.one('SELECT id FROM labs WHERE code=?', code);
    if (dup && dup.id !== id) bad('رمز المعمل مستخدم');
    return { code, name: str(b.name, 80) || bad('اكتب اسم المعمل'), name_en: str(b.name_en, 80), location: str(b.location, 120), notes: str(b.notes, 500) };
  }
  deleteDevice(id) {
    for (const r of this.q('SELECT photo_id FROM requests WHERE device_id=? AND photo_id IS NOT NULL', id)) this.sql.exec('DELETE FROM photos WHERE id=?', r.photo_id);
    this.sql.exec('DELETE FROM requests WHERE device_id=?', id);
    this.sql.exec('DELETE FROM logs WHERE device_id=?', id);
    this.sql.exec('DELETE FROM devices WHERE id=?', id);
  }

  reqList(q) {
    const where = [], args = [];
    const st = q.status || (q.no ? 'all' : 'open');
    if (st === 'open') where.push(`r.status IN ${OPEN}`);
    else if (st === 'finished') where.push("r.status IN ('done','closed')");
    else if (['new', 'progress', 'done', 'closed'].includes(st)) { where.push('r.status=?'); args.push(st); }
    if (q.lab) { where.push('r.lab_id=?'); args.push(q.lab); }
    if (q.no) { where.push('r.no=?'); args.push(int(q.no)); }
    if (q.mine && q.me) { where.push('r.assigned_id=?'); args.push(q.me); }
    return this.q(`SELECT r.*, d.code AS device_code, d.name AS device_name, d.type AS device_type, d.status AS device_status,
      l.name AS lab_name, l.name_en AS lab_name_en, l.code AS lab_code
      FROM requests r LEFT JOIN devices d ON d.id=r.device_id LEFT JOIN labs l ON l.id=r.lab_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY CASE r.status WHEN 'new' THEN 0 WHEN 'progress' THEN 1 ELSE 2 END, r.no DESC
      LIMIT ${Math.min(int(q.limit, 400), 100000)}`, ...args);
  }

  reqAction(me, no, b) {
    const r = this.one('SELECT * FROM requests WHERE no=?', no) || bad('لا يوجد بلاغ بهذا الرقم', 404);
    const d = this.one('SELECT * FROM devices WHERE id=?', r.device_id);
    const note = str(b.note, 1000);
    const t = now();
    const otherOpen = () => this.one(`SELECT COUNT(*) AS n FROM requests WHERE device_id=? AND no<>? AND status IN ${OPEN}`, r.device_id, no).n;
    switch (b.action) {
      case 'start': {
        if (!['new', 'progress'].includes(r.status)) bad('البلاغ مغلق');
        this.sql.exec("UPDATE requests SET status='progress', assigned_id=?, assigned_name=?, updated_at=? WHERE no=?", me.id, me.name, t, no);
        this.log(r.device_id, me.name, 'req_start', { note, request_no: no });
        if (d && d.status !== 'out') {
          this.sql.exec("UPDATE devices SET status='in_repair', damage=COALESCE(damage, ?), updated_at=? WHERE id=?", r.problem, t, d.id);
          if (d.status !== 'in_repair') this.log(d.id, me.name, 'status', { status: 'in_repair', damage: d.damage || r.problem, request_no: no });
        }
        return {};
      }
      case 'fix': {
        if (!['new', 'progress'].includes(r.status)) bad('البلاغ مغلق');
        const res = note || bad('اكتب ما تم إصلاحه');
        const nos = [no];
        if (b.all) for (const o of this.q(`SELECT no FROM requests WHERE device_id=? AND no<>? AND status IN ${OPEN}`, r.device_id, no)) nos.push(o.no);
        for (const n of nos) {
          this.sql.exec(`UPDATE requests SET status='done', resolution=?, closed_at=?, closed_by=?, updated_at=?,
            assigned_id=COALESCE(assigned_id, ?), assigned_name=COALESCE(assigned_name, ?) WHERE no=?`, res, t, me.name, t, me.id, me.name, n);
          this.log(r.device_id, me.name, 'req_done', { note: res, request_no: n });
        }
        if (d) {
          const status = STATUSES.includes(b.status) ? b.status : 'ok';
          const stillOpen = otherOpen() > 0 && !b.all;
          const final = status === 'ok' && stillOpen ? 'needs_fix' : status;
          this.sql.exec('UPDATE devices SET status=?, damage=?, damage_note=?, last_maint_at=?, last_maint_by=?, updated_at=? WHERE id=?',
            final, final === 'ok' ? null : d.damage, final === 'ok' ? null : d.damage_note, t, me.name, t, d.id);
          this.log(d.id, me.name, 'maint', { status: final, damage: final === 'ok' ? null : d.damage, note: res, request_no: no });
        }
        return {};
      }
      case 'close': {
        if (!['new', 'progress'].includes(r.status)) bad('البلاغ مغلق');
        const why = note || bad('اكتب سبب الإغلاق');
        this.sql.exec("UPDATE requests SET status='closed', resolution=?, closed_at=?, closed_by=?, updated_at=? WHERE no=?", why, t, me.name, t, no);
        this.log(r.device_id, me.name, 'req_closed', { note: why, request_no: no });
        if (d && ['needs_fix', 'in_repair'].includes(d.status) && !otherOpen()) {
          this.sql.exec("UPDATE devices SET status='ok', damage=NULL, damage_note=NULL, updated_at=? WHERE id=?", t, d.id);
          this.log(d.id, me.name, 'status', { status: 'ok', request_no: no });
        }
        return {};
      }
      case 'reopen': {
        if (['new', 'progress'].includes(r.status)) bad('البلاغ مفتوح');
        this.sql.exec("UPDATE requests SET status='new', closed_at=NULL, closed_by=NULL, updated_at=? WHERE no=?", t, no);
        this.log(r.device_id, me.name, 'req_reopen', { note, request_no: no });
        if (d && d.status === 'ok') {
          this.sql.exec("UPDATE devices SET status='needs_fix', damage=?, updated_at=? WHERE id=?", r.problem, t, d.id);
          this.log(d.id, me.name, 'status', { status: 'needs_fix', damage: r.problem, request_no: no });
        }
        return {};
      }
      case 'note': {
        this.log(r.device_id, me.name, 'note', { note: note || bad('اكتب الملاحظة'), request_no: no });
        return {};
      }
    }
    bad('إجراء غير معروف');
  }
}

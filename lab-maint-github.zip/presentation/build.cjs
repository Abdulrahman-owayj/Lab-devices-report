// Builds the Lab Care school-project deck in Arabic and English: lab-care-ar.pptx + lab-care-en.pptx
// Real phone screenshots come from shots.cjs; icons are the app's own line icons (core.js) rasterised with sharp.
const pptxgen = require('pptxgenjs');
const sharp = require('sharp');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const { applyTheme } = require(process.env.PPTX_SKILL + '/scripts/apply_theme.js');

const W = 13.333, H = 7.5;
const SITE = 'https://lab-maint.lab-maint.workers.dev';
const THEME = {
  name: 'Lab Care',
  headFontFace: 'Arial',
  bodyFontFace: 'Arial',
  colors: {
    dk1: '141826', lt1: 'FFFFFF', dk2: '2B3A8F', lt2: 'EEF0F7',
    accent1: '2B3A8F', accent2: 'F3A12A', accent3: '1F9D4C', accent4: 'D4342C', accent5: '2F6FDE', accent6: '586079',
    hlink: '2B3A8F', folHlink: '586079',
  },
};

// ---------- icons (same paths as public/js/core.js)
const ICONS = {
  wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  note: '<path d="M5 3h10l4 4v14H5z"/><path d="M9 12h6M9 16h4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  qr: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/>',
  xls: '<path d="M6 3h9l4 4v14H6z"/><path d="M9 11l5 6M14 11l-5 6"/>',
  phone: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  lab: '<path d="M9 3h6M10 3v6L4.5 18.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7 15h10"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  server: '<rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M7 7.5h.01M7 16.5h.01"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
};
async function icon(name, hex) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="256" height="256" fill="none" stroke="#${hex}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name]}</svg>`;
  return 'image/png;base64,' + (await sharp(Buffer.from(svg)).png().toBuffer()).toString('base64');
}
async function qrPng(text) {
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/vendor/qrcode.js'), 'utf8') + ';this.qrcode=qrcode;', ctx);
  const q = ctx.qrcode(0, 'M'); q.addData(text); q.make();
  const n = q.getModuleCount();
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + 2} ${r + 2}h1v1h-1z`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n + 4} ${n + 4}" width="600" height="600" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#141826"/></svg>`;
  return 'image/png;base64,' + (await sharp(Buffer.from(svg)).png().toBuffer()).toString('base64');
}
const shot = (lang, name) => path.join(__dirname, 'shots', `${lang}-${name}.png`);

// ---------- text for both languages
const T = {
  ar: {
    file: 'lab-care-ar-v3.pptx',
    langT: 'اللغات التي استخدمناها',
    langs4: [
      ['HTML', 'هيكل الصفحات', 'الأزرار والنماذج والقوائم التي تراها على الشاشة', '<h1>Lab Care</h1>'],
      ['CSS', 'الشكل والألوان', 'الألوان والخطوط والوضع الداكن، وتناسب الشاشة مع الجوال', 'color: #2B3A8F;'],
      ['JavaScript', 'عقل النظام', 'يعمل في الجوال وفي الخادم: يرسل البلاغات ويحفظها', "fetch('/api/report')"],
      ['SQL', 'قاعدة البيانات', 'نحفظ فيها المعامل والأجهزة والبلاغات والسجل', 'SELECT * FROM labs'],
    ],
    langFact: 'حوالي 2,300 سطر برمجي، و8 جداول في قاعدة البيانات',
    buildT: 'كيف بنيناه؟',
    arch: [
      ['phone', 'جوال الطالب أو المعلم', 'صفحات مكتوبة بلغات HTML وCSS وJavaScript'],
      ['server', 'الخادم على الإنترنت', 'يعمل بلغة JavaScript على منصة Cloudflare'],
      ['database', 'قاعدة البيانات', 'SQLite، ونكتب أوامرها بلغة SQL'],
    ],
    steps: [
      ['خطّطنا', 'حددنا الصفحات والبيانات: المعامل والأجهزة والبلاغات والسجل'],
      ['صمّمنا', 'رسمنا شكل الشاشات وألوانها لتناسب الجوال'],
      ['برمجنا', 'كتبنا الصفحات والخادم وقاعدة البيانات، وجعلنا كلمات المرور مشفّرة'],
      ['جرّبنا ونشرنا', 'اختبرنا كل خطوة، ثم نشرناه على الإنترنت'],
    ],
    notesLang: 'استخدمنا أربع لغات: HTML لبناء الصفحات، وCSS للألوان والتصميم، وJavaScript لتشغيل النظام في الجوال والخادم، وSQL لحفظ البيانات.',
    notesBuild: 'يفتح المستخدم الصفحة من جواله، فتتواصل مع الخادم على الإنترنت، والخادم يحفظ البيانات في قاعدة البيانات. وبنينا المشروع على أربع مراحل: خطّطنا، ثم صمّمنا، ثم برمجنا، ثم جرّبنا ونشرنا.',
    kicker: 'مشروع طلابي', title: 'صيانة المعامل', sub: 'جهاز معطّل في المعمل؟ بلّغ عنه من جوالك في دقيقة، وتابع إصلاحه حتى يعود للعمل', langs: 'عربي · English',
    probT: 'ماذا لاحظنا؟',
    prob: [
      ['alert', 'البلاغ يُنسى', 'يتعطل الجهاز فيخبر الطالب معلّمه، ثم تمضي الحصة ويُنسى الأمر'],
      ['clock', 'لا أحد يتذكر', 'متى صُين هذا الجهاز آخر مرة؟ وما الذي تعطّل فيه من قبل؟ لا أحد يعرف'],
      ['search', 'الطالب لا يصله خبر', 'يبلّغ عن العطل، ثم لا يعرف: هل أُصلح الجهاز أم لا؟'],
    ],
    probQ: 'فسألنا أنفسنا: كيف نجعل البلاغ سهلاً، ولا يضيع تاريخ أي جهاز؟',
    solT: 'فكرتنا: صفحتان فقط',
    sol: [
      ['users', 'للطلاب', ['تبلّغ عن العطل في أقل من دقيقة', 'تمسح رمز QR الملصق على الجهاز', 'تتابع بلاغك برقمه']],
      ['wrench', 'لفريق الصيانة', ['دخول آمن باسم مستخدم وكلمة مرور', 'البلاغات تصل أولاً بأول', 'لكل جهاز ملف كامل لا يضيع']],
    ],
    flowT: 'من العطل إلى الإصلاح',
    flow: [
      ['qr', 'امسح الرمز', 'على كل جهاز ملصق QR يفتح صفحة البلاغ مباشرة'],
      ['alert', 'بلّغ', 'اختر المشكلة، واكتب سطراً، وأرفق صورة إن أردت'],
      ['wrench', 'الفريق يتولّى الأمر', 'يستلم البلاغ ويعمل عليه حتى يُصلَح الجهاز'],
      ['note', 'كل شيء محفوظ', 'ما حدث للجهاز يبقى في ملفه للمرة القادمة'],
    ],
    stT: 'ألوان حالة الجهاز', st: ['يعمل', 'يحتاج صيانة', 'قيد الصيانة', 'خارج الخدمة'],
    stuT: 'هكذا يبلّغ الطالب', stu: ['أولاً: يفتح الصفحة', 'ثانياً: يختار الجهاز', 'ثالثاً: يحدد المشكلة ويرسل'],
    teamT: 'وهكذا يعمل فريق الصيانة',
    team: [
      ['inbox', 'البلاغات تصل فوراً', 'مع تنبيه صوتي لكل بلاغ جديد'],
      ['alert', 'تحديث حالة الجهاز', 'مثلاً: «يحتاج صيانة» مع نوع العطل'],
      ['wrench', 'تسجيل ما تم', 'ماذا أُصلح، ومن قام بالإصلاح'],
      ['key', 'حساب لكل عضو', 'بكلمة مرور يمكن إعادة تعيينها'],
    ],
    teamCap: ['بلاغ وصل من طالب', 'أجهزة معمل الروبوتات'],
    logT: 'لكل جهاز ملف لا يضيع',
    log: [
      ['check', 'حالته الآن', 'يعمل، أو يحتاج صيانة، أو قيد الصيانة، أو خارج الخدمة'],
      ['clock', 'آخر صيانة', 'متى كانت، ومن قام بها'],
      ['search', 'أعطاله السابقة', 'كل بلاغ قديم، وكيف حُلّ'],
      ['note', 'ملاحظات المهندسين', 'كل مهندس يترك ملاحظة لمن يأتي بعده'],
    ],
    featT: 'لمسات أضفناها',
    feat: [
      ['globe', 'عربي وإنجليزي', 'تتغيّر اللغة بضغطة واحدة'], ['qr', 'ملصقات QR', 'جاهزة للطباعة لكل معمل'], ['phone', 'من الجوال مباشرة', 'دون تحميل أي تطبيق'],
      ['xls', 'تصدير إلى Excel', 'للأجهزة والبلاغات والسجل'], ['key', 'كلمة مرور', 'ويمكن إعادة تعيينها'], ['moon', 'الوضع الداكن', 'أريح للعين'],
    ],
    endT: 'فريق المشروع', names: ['اسم الطالب', 'اسم الطالب', 'اسم الطالب', 'اسم الطالب'], role: 'دوره في المشروع', thanks: 'شكراً لاستماعكم', scan: 'جرّبوه الآن من جوالاتكم',
    notes: [
      'السلام عليكم. نقدّم لكم مشروعنا «صيانة المعامل»: نظام بسيط يعمل من الجوال، يساعد المدرسة على متابعة أجهزة معاملها.',
      'لاحظنا أن الجهاز إذا تعطّل، يخبر الطالب معلّمه شفهياً، وكثيراً ما يُنسى البلاغ. ولا يوجد سجل يوضح متى صُين الجهاز أو ما أعطاله السابقة.',
      'لذلك صمّمنا صفحتين فقط: صفحة يبلّغ منها الطلاب عن العطل، وصفحة لفريق الصيانة لا يدخلها إلا من لديه كلمة مرور.',
      'هذه رحلة البلاغ: يمسح الطالب الرمز، ويرسل البلاغ، فيستلمه الفريق ويُصلح الجهاز، ثم يُحفظ كل ذلك في ملف الجهاز. والألوان في الأسفل توضح حالة كل جهاز.',
      'يختار الطالب المعمل، ثم الجهاز، ثم نوع المشكلة، ويحصل على رقم يتابع به بلاغه.',
      'يصل لفريق الصيانة تنبيه مع كل بلاغ جديد، فيبدأ العمل، ويحدّث حالة الجهاز، ويكتب ما تم إصلاحه.',
      'ولكل جهاز ملف كامل: حالته الآن، وآخر صيانة، وأعطاله السابقة، وملاحظات المهندسين.',
      'وأضفنا بعض اللمسات التي تجعل استخدامه أسهل.',
      'شكراً لاستماعكم. تفضّلوا بمسح الرمز وجرّبوا النظام بأنفسكم.',
    ],
  },
  en: {
    file: 'lab-care-en-v3.pptx',
    langT: 'The languages we used',
    langs4: [
      ['HTML', 'Page structure', 'The buttons, forms and lists you see on screen', '<h1>Lab Care</h1>'],
      ['CSS', 'Look and colours', 'Colours, fonts, dark mode, and fitting the phone screen', 'color: #2B3A8F;'],
      ['JavaScript', 'The brain', 'Runs on the phone and the server: sends and saves reports', "fetch('/api/report')"],
      ['SQL', 'The database', 'Stores the labs, devices, reports and history', 'SELECT * FROM labs'],
    ],
    langFact: 'About 2,300 lines of code and 8 database tables',
    buildT: 'How we built it',
    arch: [
      ['phone', 'Student or teacher phone', 'Pages written in HTML, CSS and JavaScript'],
      ['server', 'Server on the internet', 'Cloudflare Workers, running JavaScript'],
      ['database', 'Database', 'SQLite, queried with SQL'],
    ],
    steps: [
      ['Plan', 'Decided the pages and data: labs, devices, reports, history'],
      ['Design', 'Drew the screens and colours to suit phones'],
      ['Code', 'Wrote the pages, server and database; passwords stored encrypted'],
      ['Test & publish', 'Tested every step, then put it online'],
    ],
    notesLang: 'We used four languages: HTML to build the pages, CSS for colours and design, JavaScript to run the system on the phone and the server, and SQL to store the data.',
    notesBuild: 'The user opens the page on a phone, it talks to our server on the internet, and the server saves everything in the database. We built it in four stages: plan, design, code, then test and publish.',
    kicker: 'School project', title: 'Lab Care', sub: 'A simple system to report broken lab devices and track their repair', langs: 'English · عربي',
    probT: 'The problem',
    prob: [['alert', 'Reports get lost', 'Students tell a teacher, and the report is forgotten'], ['clock', 'No history', 'Nobody knows when a device was last serviced or what broke before'], ['search', 'No follow-up', "Students never find out if it was fixed"]],
    probQ: 'How can we make reporting a fault easy, and keep every device’s history?',
    solT: 'Our solution: two simple pages',
    sol: [
      ['users', 'Student page', ['Report a fault in one minute', 'Scan the QR code on the device', 'Track the report by its number']],
      ['wrench', 'Maintenance team page', ['Username and password login', 'Receive reports, update status', 'Full history for every device']],
    ],
    flowT: 'How it works',
    flow: [['qr', 'Scan the code', 'A QR sticker on each device opens the report form'], ['alert', 'Send a report', 'Problem type, description, photo → report number'], ['wrench', 'Team fixes it', 'Start work, then press “Fixed”'], ['note', 'Saved in the log', 'Status, last maintenance and engineer notes']],
    stT: 'Device status', st: ['Working', 'Needs repair', 'Being repaired', 'Out of service'],
    stuT: 'Student page', stu: ['1. Home', '2. Choose the device', '3. Pick the problem, send'],
    teamT: 'Maintenance team page',
    team: [['inbox', 'Report inbox', 'New reports arrive with an alert'], ['alert', 'Change status', '“Needs repair” with the fault type'], ['wrench', 'Record maintenance', 'What was done, and by whom'], ['key', 'Users', 'Passwords, with reset']],
    teamCap: ['A student report', 'Devices in a lab'],
    logT: 'A full history for every device',
    log: [['check', 'Current status', 'Working, needs repair, being repaired, out of service'], ['clock', 'Last maintenance', 'Date and engineer name'], ['search', 'Previous problems', 'Every old report and how it was solved'], ['note', "Engineers' notes", 'Notes left for the next engineer']],
    featT: 'Extra features',
    feat: [['globe', 'Arabic & English', 'Switch language in one tap'], ['qr', 'QR stickers', 'Printed for each lab'], ['phone', 'Works on phones', 'No app to install'], ['xls', 'Excel export', 'Devices, reports and log'], ['key', 'Password protected', 'With password reset'], ['moon', 'Dark mode', 'Easy on the eyes']],
    endT: 'Project team', names: ['Student name', 'Student name', 'Student name', 'Student name'], role: 'Role', thanks: 'Thank you', scan: 'Scan to try it',
    notes: [
      'Our project: a maintenance system for the school’s lab devices that works on phones, in Arabic and English.',
      'Today, when a device breaks, students tell a teacher. Reports get lost and there is no maintenance history.',
      'We built two pages: one for students to report, and a password-protected one for the maintenance team.',
      'The journey of a report, from scanning the code to the device history, plus the four device status colours.',
      'Students pick the lab, then the device, then the problem — and get a number to track their report.',
      'The team sees new reports, changes device status and records what was fixed.',
      'Every device keeps its status, last maintenance, previous problems and engineers’ notes.',
      'Extra features that make it easier to use.',
      'Thank you. Scan the code to try the system.',
    ],
  },
};

async function build(lang) {
  const L = T[lang], AR = lang === 'ar';
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';
  pres.title = L.title;
  pres.author = 'Lab Care';
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  const C = pres.SchemeColor;
  const NAVY = C.accent1, AMBER = C.accent2, GREEN = C.accent3, RED = C.accent4, MUTED = C.accent6, INK = C.text1, SOFT = C.background2, WHITE = C.background1;
  const al = AR ? 'right' : 'left';
  const mx = (x, w) => (AR ? W - x - w : x); // design in LTR, mirror for Arabic
  const tx = (o) => ({ isTextBox: true, align: al, rtlMode: AR, margin: 0, ...o });

  const navyIc = {}, whiteIc = {};
  for (const k of Object.keys(ICONS)) { navyIc[k] = await icon(k, '2B3A8F'); whiteIc[k] = await icon(k, 'FFFFFF'); }

  pres.defineSlideMaster({
    title: 'DARK',
    background: { color: '2B3A8F' },
    objects: [{ placeholder: { options: { name: 'title', type: 'title', x: mx(0.8, 7.2), y: 2.35, w: 7.2, h: 1.5, fontSize: 48, bold: true, color: WHITE, align: al, valign: 'top', margin: 0 }, text: '' } }],
  });
  pres.defineSlideMaster({
    title: 'CONTENT',
    background: { color: 'FFFFFF' },
    objects: [{ placeholder: { options: { name: 'title', type: 'title', x: 0.7, y: 0.45, w: W - 1.4, h: 0.85, fontSize: 34, bold: true, color: INK, align: al, valign: 'middle', margin: 0 }, text: '' } }],
    slideNumber: { x: AR ? 0.55 : W - 1.0, y: H - 0.55, w: 0.5, h: 0.3, fontSize: 11, color: MUTED, align: AR ? 'left' : 'right' },
  });

  const slide = (master, title, note) => {
    const s = pres.addSlide({ masterName: master });
    const add = s.addText.bind(s);
    s.addText = (t, o) => add(t, { lang: AR ? 'ar-SA' : 'en-US', ...o });
    s.addText(title, { placeholder: 'title', rtlMode: AR });
    s.addNotes(note);
    return s;
  };
  const circleIcon = (s, name, x, y, d, dark, onCard) => {
    s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: dark ? NAVY : onCard ? WHITE : SOFT }, line: { type: 'none' } });
    const p = d * 0.25;
    s.addImage({ data: (dark ? whiteIc : navyIc)[name], x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p });
  };
  const phone = (s, img, x, y, h, name) => {
    const w = (h * 390) / 844, b = 0.07;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x - b, y: y - b, w: w + 2 * b, h: h + 2 * b, rectRadius: 0.22, fill: { color: '1C2033' }, line: { type: 'none' },
      shadow: { type: 'outer', color: '141826', opacity: 0.22, blur: 14, offset: 4, angle: 90 }, objectName: name + ' frame' });
    s.addImage({ path: img, x, y, w, h, objectName: name });
    return w;
  };
  const card = (s, x, y, w, h, fill) => s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.16, fill: { color: fill || SOFT }, line: { type: 'none' } });

  // 1 — title
  {
    const s = slide('DARK', L.title, L.notes[0]);
    s.addText(L.kicker, tx({ x: mx(0.8, 7.2), y: 1.75, w: 7.2, h: 0.45, fontSize: 18, bold: true, color: AMBER }));
    s.addText(L.sub, tx({ x: mx(0.8, 6.6), y: 3.95, w: 6.6, h: 1.0, fontSize: 20, color: WHITE, valign: 'top' }));
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: mx(0.8, 2.4), y: 5.35, w: 2.4, h: 0.5, rectRadius: 0.25, fill: { color: WHITE, transparency: 85 }, line: { type: 'none' } });
    s.addText(L.langs, { isTextBox: true, x: mx(0.8, 2.4), y: 5.35, w: 2.4, h: 0.5, fontSize: 14, bold: true, color: WHITE, align: 'center', valign: 'middle', margin: 0, rtlMode: AR });
    phone(s, shot(lang, 'home'), mx(9.15, 2.86), 0.85, 6.2, 'home screenshot');
  }

  // 2 — problem
  {
    const s = slide('CONTENT', L.probT, L.notes[1]);
    const cw = 3.75, gap = 0.45, x0 = 0.7;
    L.prob.forEach(([ic, h, b], i) => {
      const x = mx(x0 + i * (cw + gap), cw);
      card(s, x, 1.75, cw, 3.05);
      circleIcon(s, ic, AR ? x + cw - 0.4 - 0.9 : x + 0.4, 2.1, 0.9, false, true);
      s.addText(h, tx({ x: x + 0.4, y: 3.2, w: cw - 0.8, h: 0.5, fontSize: 22, bold: true, color: INK }));
      s.addText(b, tx({ x: x + 0.4, y: 3.75, w: cw - 0.8, h: 1.15, fontSize: 16, color: MUTED, valign: 'top' }));
    });
    s.addText(L.probQ, tx({ x: 0.7, y: 5.35, w: W - 1.4, h: 0.7, fontSize: 22, italic: true, color: NAVY, align: 'center' }));
  }

  // 3 — solution: two pages
  {
    const s = slide('CONTENT', L.solT, L.notes[2]);
    const cw = 5.75, gap = 0.43;
    L.sol.forEach(([ic, h, lines], i) => {
      const x = mx(0.7 + i * (cw + gap), cw);
      card(s, x, 1.6, cw, 5.1);
      const imgW = (4.4 * 390) / 844;
      const ix = AR ? x + 0.4 : x + cw - 0.4 - imgW;
      phone(s, shot(lang, i ? 'dash' : 'home'), ix, 1.95, 4.4, i ? 'team dashboard' : 'student home');
      const tw = cw - imgW - 1.1, tx0 = AR ? x + cw - 0.4 - tw : x + 0.4;
      circleIcon(s, ic, AR ? tx0 + tw - 0.8 : tx0, 2.0, 0.8, true);
      s.addText(h, tx({ x: tx0, y: 3.0, w: tw, h: 0.9, fontSize: 22, bold: true, color: INK, valign: 'top' }));
      lines.forEach((t, k) => {
        const y = 4.0 + k * 0.72;
        s.addImage({ data: navyIc.check, x: AR ? tx0 + tw - 0.3 : tx0, y: y + 0.06, w: 0.3, h: 0.3 });
        s.addText(t, tx({ x: AR ? tx0 : tx0 + 0.45, y, w: tw - 0.45, h: 0.62, fontSize: 16, color: INK, valign: 'top' }));
      });
    });
  }

  // 4 — how it works
  {
    const s = slide('CONTENT', L.flowT, L.notes[3]);
    const cw = 2.75, gap = 0.4;
    L.flow.forEach(([ic, h, b], i) => {
      const x = mx(0.7 + i * (cw + gap), cw);
      circleIcon(s, ic, x + cw / 2 - 0.6, 1.75, 1.2, true);
      s.addShape(pres.shapes.OVAL, { x: x + cw / 2 + 0.28, y: 1.65, w: 0.48, h: 0.48, fill: { color: AMBER }, line: { color: 'FFFFFF', width: 2 } });
      s.addText(String(i + 1), { isTextBox: true, x: x + cw / 2 + 0.28, y: 1.65, w: 0.48, h: 0.48, fontSize: 16, bold: true, color: INK, align: 'center', valign: 'middle', margin: 0 });
      if (i < 3) {
        const ax = AR ? x - gap + 0.06 : x + cw + 0.06;
        s.addShape(AR ? pres.shapes.LEFT_ARROW : pres.shapes.RIGHT_ARROW, { x: ax, y: 2.2, w: gap - 0.12, h: 0.3, fill: { color: AMBER }, line: { type: 'none' } });
      }
      s.addText(h, { isTextBox: true, x, y: 3.15, w: cw, h: 0.5, fontSize: 20, bold: true, color: INK, align: 'center', rtlMode: AR, margin: 0 });
      s.addText(b, { isTextBox: true, x, y: 3.7, w: cw, h: 0.95, fontSize: 15, color: MUTED, align: 'center', valign: 'top', rtlMode: AR, margin: 0 });
    });
    card(s, 0.7, 5.05, W - 1.4, 1.45);
    s.addText(L.stT, tx({ x: mx(1.1, 2.6), y: 5.25, w: 2.6, h: 0.4, fontSize: 16, bold: true, color: INK }));
    const cols = [GREEN, RED, AMBER, MUTED], pw = 2.35, pg = 0.3;
    L.st.forEach((t, i) => {
      const x = mx(1.1 + i * (pw + pg), pw);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 5.75, w: pw, h: 0.5, rectRadius: 0.25, fill: { color: WHITE }, line: { color: cols[i], width: 1.5 } });
      s.addShape(pres.shapes.OVAL, { x: AR ? x + pw - 0.42 : x + 0.22, y: 5.9, w: 0.2, h: 0.2, fill: { color: cols[i] }, line: { type: 'none' } });
      s.addText(t, { isTextBox: true, x: AR ? x + 0.15 : x + 0.55, y: 5.75, w: pw - 0.7, h: 0.5, fontSize: 15, bold: true, color: INK, align: al, valign: 'middle', rtlMode: AR, margin: 0 });
    });
  }

  // 5 — student page: three phones
  {
    const s = slide('CONTENT', L.stuT, L.notes[4]);
    const ph = 4.75, pw = (ph * 390) / 844, gap = 1.1;
    const total = 3 * pw + 2 * gap, x0 = (W - total) / 2;
    ['home', 'devices', 'form'].forEach((n, i) => {
      const x = mx(x0 + i * (pw + gap), pw);
      phone(s, shot(lang, n), x, 1.6, ph, 'student ' + n);
      s.addText(L.stu[i], { isTextBox: true, x: x - 0.4, y: 6.5, w: pw + 0.8, h: 0.45, fontSize: 16, bold: true, color: INK, align: 'center', rtlMode: AR, margin: 0 });
    });
  }

  // 6 — maintenance team: icon rows + two phones
  {
    const s = slide('CONTENT', L.teamT, L.notes[5]);
    const tw = 5.9, x = mx(0.7, tw);
    L.team.forEach(([ic, h, b], i) => {
      const y = 1.75 + i * 1.2;
      circleIcon(s, ic, AR ? x + tw - 0.85 : x, y, 0.85, false);
      const bx = AR ? x : x + 1.15;
      s.addText(h, tx({ x: bx, y: y + 0.02, w: tw - 1.15, h: 0.42, fontSize: 20, bold: true, color: INK }));
      s.addText(b, tx({ x: bx, y: y + 0.45, w: tw - 1.15, h: 0.4, fontSize: 15, color: MUTED }));
    });
    const ph = 4.75, pw = (ph * 390) / 844;
    ['request', 'lab'].forEach((n, i) => {
      const px = mx(7.45 + i * (pw + 0.8), pw);
      phone(s, shot(lang, n), px, 1.6, ph, 'team ' + n);
      s.addText(L.teamCap[i], { isTextBox: true, x: px - 0.4, y: 6.5, w: pw + 0.8, h: 0.45, fontSize: 15, bold: true, color: INK, align: 'center', rtlMode: AR, margin: 0 });
    });
  }

  // 7 — device history
  {
    const s = slide('CONTENT', L.logT, L.notes[6]);
    const ph = 5.3, pw = (ph * 390) / 844;
    phone(s, shot(lang, 'device'), mx(0.95, pw), 1.55, ph, 'device page');
    const gx = 4.4, cw = 3.95, ch = 2.35, g = 0.3;
    L.log.forEach(([ic, h, b], i) => {
      const x = mx(gx + (i % 2) * (cw + g), cw), y = 1.6 + Math.floor(i / 2) * (ch + g);
      card(s, x, y, cw, ch);
      circleIcon(s, ic, AR ? x + cw - 0.35 - 0.75 : x + 0.35, y + 0.3, 0.75, true);
      s.addText(h, tx({ x: x + 0.35, y: y + 1.2, w: cw - 0.7, h: 0.45, fontSize: 19, bold: true, color: INK }));
      s.addText(b, tx({ x: x + 0.35, y: y + 1.65, w: cw - 0.7, h: 0.6, fontSize: 14, color: MUTED, valign: 'top' }));
    });
  }

  // 8 — features grid + QR stickers screenshot
  {
    const s = slide('CONTENT', L.featT, L.notes[7]);
    const cw = 2.6, ch = 2.3, g = 0.3;
    L.feat.forEach(([ic, h, b], i) => {
      const x = mx(0.7 + (i % 3) * (cw + g), cw), y = 1.6 + Math.floor(i / 3) * (ch + g);
      card(s, x, y, cw, ch);
      circleIcon(s, ic, x + cw / 2 - 0.4, y + 0.3, 0.8, false, true);
      s.addText(h, { isTextBox: true, x: x + 0.15, y: y + 1.2, w: cw - 0.3, h: 0.45, fontSize: 17, bold: true, color: INK, align: 'center', rtlMode: AR, margin: 0 });
      s.addText(b, { isTextBox: true, x: x + 0.15, y: y + 1.65, w: cw - 0.3, h: 0.45, fontSize: 14, color: MUTED, align: 'center', rtlMode: AR, margin: 0 });
    });
    const ph = 4.9, pw = (ph * 390) / 844;
    phone(s, shot(lang, 'labels'), mx(10.15, pw), 1.6, ph, 'QR stickers page');
  }

  // 9 — the languages we used
  {
    const s = slide('CONTENT', L.langT, L.notesLang);
    const LC = { HTML: ['E34F26', 'FFFFFF'], CSS: ['2965F1', 'FFFFFF'], JavaScript: ['F0DB4F', '141826'], SQL: ['1F9D4C', 'FFFFFF'] };
    const cw = 2.75, g = 0.31;
    L.langs4.forEach(([name, h, b, code], i) => {
      const x = mx(0.7 + i * (cw + g), cw);
      card(s, x, 1.6, cw, 3.95);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.3, y: 1.9, w: cw - 0.6, h: 0.75, rectRadius: 0.12, fill: { color: LC[name][0] }, line: { type: 'none' } });
      s.addText(name, { isTextBox: true, x: x + 0.3, y: 1.9, w: cw - 0.6, h: 0.75, fontSize: 22, bold: true, color: LC[name][1], align: 'center', valign: 'middle', margin: 0, lang: 'en-US', rtlMode: false });
      s.addText(h, tx({ x: x + 0.3, y: 2.9, w: cw - 0.6, h: 0.45, fontSize: 18, bold: true, color: INK }));
      s.addText(b, tx({ x: x + 0.3, y: 3.4, w: cw - 0.6, h: 1.15, fontSize: 14, color: MUTED, valign: 'top' }));
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.3, y: 4.55, w: cw - 0.6, h: 0.7, rectRadius: 0.1, fill: { color: '1C2033' }, line: { type: 'none' } });
      s.addText(code, { isTextBox: true, x: x + 0.38, y: 4.55, w: cw - 0.76, h: 0.7, fontFace: 'Courier New', fontSize: 11, color: 'FFFFFF', align: 'left', valign: 'middle', margin: 0, lang: 'en-US', rtlMode: false });
    });
    s.addText(L.langFact, { isTextBox: true, x: 0.7, y: 5.95, w: W - 1.4, h: 0.5, fontSize: 18, italic: true, color: NAVY, align: 'center', rtlMode: AR, margin: 0 });
  }

  // 10 — how we built it: architecture + four stages
  {
    const s = slide('CONTENT', L.buildT, L.notesBuild);
    const bw = 3.4, ag = 0.85;
    L.arch.forEach(([ic, h, b], i) => {
      const x = mx(0.7 + i * (bw + ag), bw);
      card(s, x, 1.55, bw, 1.95);
      circleIcon(s, ic, AR ? x + bw - 0.3 - 0.75 : x + 0.3, 1.8, 0.75, true);
      const tw = bw - 1.5, tx0 = AR ? x + 0.25 : x + 1.25;
      s.addText(h, tx({ x: tx0, y: 1.8, w: tw, h: 0.75, fontSize: 17, bold: true, color: INK, valign: 'top' }));
      s.addText(b, tx({ x: AR ? x + 0.3 : x + 0.3, y: 2.65, w: bw - 0.6, h: 0.7, fontSize: 13, color: MUTED, valign: 'top' }));
      if (i < 2) {
        const ax = AR ? x - ag + 0.12 : x + bw + 0.12;
        s.addShape(pres.shapes.LEFT_RIGHT_ARROW, { x: ax, y: 2.33, w: ag - 0.24, h: 0.38, fill: { color: AMBER }, line: { type: 'none' } });
      }
    });
    const cw = 2.75, g = 0.31;
    L.steps.forEach(([h, b], i) => {
      const x = mx(0.7 + i * (cw + g), cw);
      card(s, x, 3.95, cw, 2.25, WHITE);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 3.95, w: cw, h: 2.25, rectRadius: 0.16, fill: { type: 'none' }, line: { color: 'E2E5EE', width: 1.25 } });
      const nx = AR ? x + cw - 0.3 - 0.5 : x + 0.3;
      s.addShape(pres.shapes.OVAL, { x: nx, y: 4.2, w: 0.5, h: 0.5, fill: { color: AMBER }, line: { type: 'none' } });
      s.addText(String(i + 1), { isTextBox: true, x: nx, y: 4.2, w: 0.5, h: 0.5, fontSize: 16, bold: true, color: INK, align: 'center', valign: 'middle', margin: 0 });
      s.addText(h, tx({ x: x + 0.3, y: 4.85, w: cw - 0.6, h: 0.45, fontSize: 18, bold: true, color: INK }));
      s.addText(b, tx({ x: x + 0.3, y: 5.32, w: cw - 0.6, h: 0.95, fontSize: 13, color: MUTED, valign: 'top' }));
    });
  }

  // 11 — team + thank you
  {
    const s = slide('DARK', L.endT, L.notes[8]);
    s.addText(L.thanks, tx({ x: mx(0.8, 7.2), y: 1.75, w: 7.2, h: 0.5, fontSize: 20, bold: true, color: AMBER }));
    const nw = 3.4, nh = 1.0, g = 0.3;
    L.names.forEach((n, i) => {
      const x = mx(0.8 + (i % 2) * (nw + g), nw), y = 4.0 + Math.floor(i / 2) * (nh + g);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: nw, h: nh, rectRadius: 0.14, fill: { color: WHITE, transparency: 88 }, line: { type: 'none' } });
      s.addText([{ text: n, options: { fontSize: 19, bold: true, color: WHITE, breakLine: true } }, { text: L.role, options: { fontSize: 13, color: 'CADCFC' } }],
        tx({ x: x + 0.3, y, w: nw - 0.6, h: nh, valign: 'middle', objectName: `student name ${i + 1}` }));
    });
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: mx(9.35, 3.2), y: 2.4, w: 3.2, h: 3.9, rectRadius: 0.2, fill: { color: WHITE }, line: { type: 'none' } });
    s.addImage({ data: await qrPng(SITE), x: mx(9.6, 2.7), y: 2.65, w: 2.7, h: 2.7, objectName: 'site QR' });
    s.addText(L.scan, { isTextBox: true, x: mx(9.35, 3.2), y: 5.47, w: 3.2, h: 0.5, fontSize: 16, bold: true, color: INK, align: 'center', rtlMode: AR, margin: 0 });
    s.addText('lab-maint.lab-maint.workers.dev', { isTextBox: true, x: mx(8.55, 4.8), y: 6.5, w: 4.8, h: 0.4, fontSize: 12, color: 'CADCFC', align: 'center', margin: 0 });
  }

  await pres.writeFile({ fileName: L.file });
  await applyTheme(L.file, THEME);
  console.log('wrote', L.file);
}

(async () => {
  for (const lang of process.argv.slice(2).length ? process.argv.slice(2) : ['ar', 'en']) await build(lang);
})();

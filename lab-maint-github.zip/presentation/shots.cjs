// Phone-size screenshots of the live app (with the demo labs) for the slides → shots/<lang>-<name>.png
const puppeteer = require('../../ai-motion-video/node_modules/puppeteer-core');
const fs = require('fs');
const BASE = 'https://lab-maint.lab-maint.workers.dev';
const UA = 'Mozilla/5.0';
const PASSWORD = process.env.LAB_ADMIN_PASSWORD; // admin password of the live site, never stored in the repo
if (!PASSWORD) { console.error('Set LAB_ADMIN_PASSWORD first'); process.exit(1); }

(async () => {
  fs.mkdirSync('shots', { recursive: true });
  const L = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json', 'user-agent': UA }, body: JSON.stringify({ username: 'admin', password: PASSWORD }) })).json();
  const H = { 'x-token': L.token, 'user-agent': UA };
  const { labs } = await (await fetch(BASE + '/api/labs', { headers: H })).json();
  const comp = labs.find((l) => l.code === 'COMP');
  const robo = labs.find((l) => l.code === 'ROBO');
  const { devices } = await (await fetch(BASE + '/api/labs/' + robo.id, { headers: H })).json();
  const broken = devices.find((d) => d.status !== 'ok');
  const { requests } = await (await fetch(BASE + '/api/requests', { headers: H })).json();
  const req = requests.find((r) => r.device_id === broken.id);

  const browser = await puppeteer.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: 'new' });
  const page = await browser.newPage();
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(BASE + '/', { waitUntil: 'networkidle0' });
  for (const lang of ['ar', 'en']) {
    await page.evaluate((tok, user, lang) => {
      localStorage.setItem('lab.token', JSON.stringify(tok)); localStorage.setItem('lab.user', JSON.stringify(user));
      localStorage.setItem('lab.lang', JSON.stringify(lang)); localStorage.setItem('lab.theme', JSON.stringify('light'));
    }, L.token, L.user, lang);
    const shots = [
      ['home', '/#/'],
      ['devices', '/#/report/' + comp.id],
      ['form', '/#/dev/' + broken.id],
      ['dash', '/admin#/'],
      ['request', '/admin#/req/' + req.no],
      ['device', '/admin#/dev/' + broken.id],
      ['lab', '/admin#/lab/' + robo.id],
      ['labels', '/admin#/labels/' + comp.id],
    ];
    for (const [name, path] of shots) {
      await page.goto('about:blank');
      await page.goto(BASE + path, { waitUntil: 'networkidle0' });
      await new Promise((r) => setTimeout(r, 900));
      // dashboard: hide the one-line report descriptions so the slide stays readable
      if (name === 'dash') await page.evaluate(() => document.querySelectorAll('.reqrow .body > .s:nth-child(3)').forEach((e) => e.remove()));
      await page.screenshot({ path: `shots/${lang}-${name}.png` });
      console.log(lang, name);
    }
  }
  await browser.close();
  await fetch(BASE + '/api/logout', { method: 'POST', headers: H });
})();

// Maintenance team + admin pages (/admin): requests inbox, labs → devices → device log, users, about editor, export.
'use strict';

const TNAV = [
  { r: '', ic: 'home', l: 'الرئيسية' },
  { r: 'requests', ic: 'inbox', l: 'البلاغات' },
  { r: 'labs', ic: 'lab', l: 'المعامل' },
  { r: 'menu', ic: 'menu', l: 'القائمة' },
];
let newCount = 0, pollTimer = null;

function renderTeamNav(cur) {
  const nav = $('#nav');
  nav.innerHTML = TNAV.map((n) => `<a href="#/${n.r}" class="${cur === n.r ? 'on' : ''}">${ICON[n.ic]}${t(n.l)}${n.r === 'requests' && newCount ? `<span class="nb">${newCount}</span>` : ''}</a>`).join('');
}
function startPolling() {
  if (pollTimer) return;
  const tick = async () => {
    if (!S.token) return;
    try {
      const { new: n } = await api('GET', '/count');
      if (n > newCount && pollTimer && newCount >= 0) { if (n > newCount) toast(t('وصل بلاغ جديد')); chime(); }
      newCount = n;
      const b = $('#nav a[href="#/requests"]');
      if (b) { $('.nb', b)?.remove(); if (n) b.insertAdjacentHTML('beforeend', `<span class="nb">${n}</span>`); }
      document.title = (n ? `(${n}) ` : '') + t('صيانة المعامل');
    } catch { /* offline — next tick */ }
  };
  pollTimer = setInterval(tick, 25000);
}
let audioCtx;
function chime() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    [660, 880].forEach((f, i) => {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.frequency.value = f; o.connect(g); g.connect(audioCtx.destination);
      const t0 = audioCtx.currentTime + i * 0.16;
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.15, t0 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.3);
      o.start(t0); o.stop(t0 + 0.32);
    });
  } catch { /* no audio */ }
}

async function teamRoute(p) {
  const el = $('#app');
  if (!S.token) { $('#nav').classList.add('hidden'); document.body.classList.add('nonav'); return tLogin(el); }
  $('#nav').classList.remove('hidden'); document.body.classList.remove('nonav');
  renderTeamNav(['requests', 'req'].includes(p[0]) ? 'requests' : ['labs', 'lab', 'dev', 'labels'].includes(p[0]) ? 'labs' : ['menu', 'users', 'password', 'about', 'about-edit'].includes(p[0]) ? 'menu' : '');
  startPolling();
  el.innerHTML = `<div class="loading">${t('جارٍ التحميل…')}</div>`;
  try {
    switch (p[0]) {
      case 'requests': return await tRequests(el, p[1] || 'open');
      case 'req': return await tRequest(el, p[1]);
      case 'labs': return await tLabs(el);
      case 'lab': return await tLab(el, p[1], p[2] || 'all');
      case 'dev': return await tDevice(el, p[1], p[2] || 'log');
      case 'labels': return await tLabels(el, p[1]);
      case 'menu': return tMenu(el);
      case 'users': return await tUsers(el);
      case 'password': return tPassword(el);
      case 'about': return await tAbout(el);
      case 'about-edit': return await tAboutEdit(el);
      default: return await tDash(el);
    }
  } catch (e) {
    el.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`;
  }
}

// ---------- login + forgot password
function tLogin(el) {
  el.innerHTML = `<div class="login">
    <div style="text-align:center"><span class="logo-lg">${ICON.wrench}</span>
      <h1 style="margin:6px 0 2px">${t('دخول فريق الصيانة')}</h1><div class="muted">${t('صيانة المعامل')}</div></div>
    <div class="card" style="margin-top:16px">
      <div class="field"><label class="f">${t('اسم المستخدم')}</label><input class="in" id="u" autocomplete="username" autocapitalize="none" spellcheck="false" dir="ltr"></div>
      <div class="field"><label class="f">${t('كلمة المرور')}</label>${pwField('pw')}</div>
      <button class="btn primary big" id="go">${t('دخول')}</button>
      <div style="text-align:center;margin-top:12px"><button class="linkbtn" id="forgot" style="color:var(--primary);background:none;border:0;cursor:pointer;font:inherit;font-weight:700">${t('نسيت كلمة المرور؟')}</button></div>
    </div>
    <div class="footer-link"><a href="/">${t('صفحة بلاغات الطلاب')}</a></div></div>`;
  bindEyes(el);
  const go = (btn) => busy(btn, async () => {
    const r = await api('POST', '/login', { username: $('#u', el).value, password: $('#pw', el).value });
    S.token = r.token; S.user = r.user; LS.set('token', r.token); LS.set('user', r.user);
    newCount = -1;
    renderHeader(); location.hash = '#/'; route(true);
  });
  $('#go', el).onclick = (e) => go(e.currentTarget);
  $('#pw', el).onkeydown = (e) => { if (e.key === 'Enter') go($('#go', el)); };
  $('#u', el).onkeydown = (e) => { if (e.key === 'Enter') $('#pw', el).focus(); };
  $('#forgot', el).onclick = () => sheet(`<h2>${t('نسيت كلمة المرور؟')}</h2>
    <div class="alert info" style="margin-bottom:12px">${t('اطلب من مدير النظام إعادة تعيين كلمة مرورك من صفحة «المستخدمون». وإذا نسي المدير كلمة مروره يستخدم رمز الاستعادة:')}</div>
    <div class="field"><label class="f">${t('رمز الاستعادة')}</label><input class="in" id="rk" autocomplete="off" dir="ltr"></div>
    <div class="field"><label class="f">${t('اسم المستخدم')}</label><input class="in" id="ru" autocapitalize="none" dir="ltr" value="${esc($('#u', el).value)}"></div>
    <div class="field"><label class="f">${t('كلمة المرور الجديدة')}</label>${pwField('rp', '', 'new-password')}</div>
    <div class="grid2"><button class="btn primary" id="rgo">${t('تعيين كلمة المرور')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    bindEyes(sh);
    $('#rgo', sh).onclick = (e) => busy(e.currentTarget, async () => {
      await api('POST', '/recover', { key: $('#rk', sh).value, username: $('#ru', sh).value, password: $('#rp', sh).value });
      close(); toast(t('تم تعيين كلمة المرور — سجّل الدخول'));
      $('#u', el).value = $('#ru', sh).value;
    });
  });
}

// ---------- dashboard
const kpi = (v, l, href, cls = '', dot = '') => `<a class="kpi ${cls}" href="${href}"><div class="v">${v}</div><div class="l">${dot ? `<span class="dot ${dot}"></span>` : ''}${l}</div></a>`;
function labBar(l) {
  const tot = l.total || 0;
  const seg = (k) => (l[k] ? `<i class="st-${k}" style="width:${(l[k] / tot) * 100}%"></i>` : '');
  return `<div class="bar">${tot ? seg('ok') + seg('needs_fix') + seg('in_repair') + seg('out') : ''}</div>`;
}
const legend = () => `<div class="legend">${Object.keys(STATUS).map((k) => `<span><span class="dot st-${k}"></span>${t(STATUS[k])}</span>`).join('')}</div>`;

async function tDash(el) {
  const d = await api('GET', '/dash');
  newCount = d.requests.new;
  const totalDev = Object.values(d.devices).reduce((a, b) => a + b, 0);
  el.innerHTML = `<h1>${t('أهلاً {name}', { name: esc(S.user.name) })}</h1>
    <div class="kpis">
      ${kpi(d.requests.new, t('بلاغات جديدة'), '#/requests/new', d.requests.new ? 'hl' : '')}
      ${kpi(d.requests.progress, t('قيد العمل'), '#/requests/progress', '', 'st-in_repair')}
      ${kpi(d.devices.needs_fix + d.devices.in_repair, t('أجهزة معطّلة'), '#/labs', '', 'st-needs_fix')}
      ${kpi(`${d.devices.ok}<span class="muted" style="font-size:15px"> / ${totalDev}</span>`, t('أجهزة تعمل'), '#/labs', '', 'st-ok')}
    </div>
    <div class="grid2" style="margin-bottom:12px">
      ${kpi(d.fixed_week, t('أُصلحت هذا الأسبوع'), '#/requests/finished', '', 'st-ok')}
      ${kpi(d.devices.out, t('خارج الخدمة'), '#/labs', '', 'st-out')}
    </div>
    <div class="sec-h"><h2>${t('البلاغات المفتوحة')}</h2><a class="btn sm" href="#/requests">${t('عرض الكل')}</a></div>
    ${d.recent.length ? `<div class="list">${d.recent.map(reqRow).join('')}</div>` : `<div class="card empty">${ICON.check.replace('<svg', '<svg style="width:34px;height:34px;color:var(--ok)"')}<div>${t('لا توجد بلاغات مفتوحة')}</div></div>`}
    <div class="sec-h"><h2>${t('حالة المعامل')}</h2><a class="btn sm" href="#/labs">${t('المعامل')}</a></div>
    ${d.labs.length ? `<div class="card">${d.labs.map((l) => `<a class="villa-row" href="#/lab/${l.id}" style="display:block;text-decoration:none;color:inherit">
        <div class="hd"><b>${esc(labName(l))} <span class="mono muted small">${esc(l.code)}</span></b>
        <span class="small muted">${(l.needs_fix || 0) + (l.in_repair || 0) ? `<span style="color:var(--bad);font-weight:700">${t('{n} معطّل', { n: (l.needs_fix || 0) + (l.in_repair || 0) })}</span> · ` : ''}${t('{n} جهاز', { n: l.total })}</span></div>
        ${labBar(l)}</a>`).join('')}${legend()}</div>`
      : `<div class="card empty">${t('لم تُضف أي معامل بعد')}${S.isAdmin ? `<div style="margin-top:10px"><a class="btn primary" href="#/labs">${ICON.plus}${t('إضافة معمل')}</a></div>` : ''}</div>`}`;
}

function reqRow(r) {
  return `<a class="li reqrow" href="#/req/${r.no}">
    <span class="th">${ICON[DAMAGE_IC[r.problem]] || ICON.other}</span>
    <span class="body"><span class="t">${dmg(r.problem)} · ${esc(r.device_name || '')} <span class="mono muted small">${esc(r.device_code || '')}</span></span>
      <span class="s">${esc(labName(r))} · ${ago(r.created_at)}${r.assigned_name && r.status === 'progress' ? ' · ' + esc(r.assigned_name) : ''}</span>
      ${r.description ? `<span class="s" style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(r.description)}</span>` : ''}</span>
    <span style="display:grid;gap:4px;justify-items:end"><span class="no">#${r.no}</span>${rqBadge(r.status)}</span></a>`;
}

// ---------- requests inbox
async function tRequests(el, st) {
  const lab = LS.get('reqLab', '');
  const [{ requests }, { labs }] = await Promise.all([api('GET', `/requests?status=${st}&lab=${encodeURIComponent(lab)}`), api('GET', '/labs')]);
  const tabs = [['open', 'المفتوحة'], ['new', 'جديدة'], ['progress', 'قيد العمل'], ['finished', 'المنتهية'], ['all', 'الكل']];
  el.innerHTML = `<h1>${t('البلاغات')}</h1>
    <div class="tabs">${tabs.map(([k, l]) => `<button class="${k === st ? 'on' : ''}" data-t="${k}">${t(l)}${k === st ? `<span class="n">${requests.length}</span>` : ''}</button>`).join('')}</div>
    <div class="field"><select class="in" id="lab"><option value="">${t('كل المعامل')}</option>${labs.map((l) => `<option value="${l.id}" ${l.id === lab ? 'selected' : ''}>${esc(labName(l))}</option>`).join('')}</select></div>
    ${requests.length ? `<div class="list">${requests.map(reqRow).join('')}</div>` : `<div class="empty">${t('لا توجد بلاغات هنا')}</div>`}`;
  $$('.tabs button', el).forEach((b) => (b.onclick = () => { location.hash = '#/requests/' + b.dataset.t; }));
  $('#lab', el).onchange = (e) => { LS.set('reqLab', e.target.value); route(true); };
}

async function tRequest(el, no) {
  const { request: r, others, log } = await api('GET', '/requests/' + encodeURIComponent(no));
  const open = ['new', 'progress'].includes(r.status);
  const otherOpen = others.filter((o) => ['new', 'progress'].includes(o.status)).length;
  el.innerHTML = `<div class="crumbs"><a href="#/requests">${LANG === 'en' ? '←' : '→'} ${t('البلاغات')}</a></div>
    <div class="row" style="margin-bottom:10px"><h1 class="grow" style="margin:0">${t('بلاغ رقم')} ${r.no}</h1>${rqBadge(r.status)}</div>
    <div class="card">
      <div class="row"><span class="li-ic" style="width:48px;height:48px;border-radius:14px;background:var(--primary-soft);color:var(--primary);display:grid;place-items:center">${ICON[DAMAGE_IC[r.problem]] || ICON.other}</span>
        <div class="grow"><b style="font-size:18px">${dmg(r.problem)}</b><div class="muted small">${fmtTime(r.created_at)} · ${ago(r.created_at)}</div></div></div>
      ${r.description ? `<div class="tl"><div class="note" style="margin-top:10px">${esc(r.description)}</div></div>` : ''}
      ${r.photo_id ? `<img src="/img/${r.photo_id}" alt="" style="margin-top:10px;width:140px;height:140px;object-fit:cover;border-radius:12px;cursor:zoom-in" id="rph">` : ''}
      <dl class="kv" style="margin-top:12px">
        <dt>${t('الجهاز')}</dt><dd><a href="#/dev/${r.device_id}"><b>${esc(r.device_name || '')}</b> <span class="mono">${esc(r.device_code || '')}</span></a> ${stBadge(r.device_status)}</dd>
        <dt>${t('المعمل')}</dt><dd>${esc(labName(r))}</dd>
        <dt>${t('المُبلّغ')}</dt><dd>${esc(r.reporter || t('بدون اسم'))}${r.grade ? ' · ' + esc(r.grade) : ''}</dd>
        ${r.assigned_name ? `<dt>${t('المسؤول')}</dt><dd>${esc(r.assigned_name)}</dd>` : ''}
        ${r.closed_at ? `<dt>${t('أُغلق')}</dt><dd>${fmtTime(r.closed_at)} · ${esc(r.closed_by || '')}</dd>` : ''}
        ${r.resolution ? `<dt>${r.status === 'done' ? t('ما تم إصلاحه') : t('سبب الإغلاق')}</dt><dd style="white-space:pre-wrap">${esc(r.resolution)}</dd>` : ''}
      </dl>
    </div>
    <div class="actrow" style="margin-bottom:12px">
      ${open && r.status === 'new' ? `<button class="btn primary" data-a="start">${ICON.wrench}${t('ابدأ العمل')}</button>` : ''}
      ${open ? `<button class="btn ok" data-a="fix">${ICON.check}${t('تم الإصلاح')}</button>` : ''}
      ${open ? `<button class="btn" data-a="close">${t('إغلاق بدون إصلاح')}</button>` : ''}
      ${!open ? `<button class="btn" data-a="reopen">${t('إعادة فتح البلاغ')}</button>` : ''}
      <button class="btn" data-a="note">${ICON.note}${t('إضافة ملاحظة')}</button>
    </div>
    <h2>${t('سجل البلاغ')}</h2>
    <div class="card">${timeline(log)}</div>
    ${others.length ? `<h2>${t('بلاغات أخرى لنفس الجهاز')}</h2><div class="list">${others.map((o) => `<a class="li" href="#/req/${o.no}" style="padding:8px 12px">
      <span class="body"><span class="t">#${o.no} · ${dmg(o.problem)}</span><span class="s">${fmtTime(o.created_at)}</span></span>${rqBadge(o.status)}</a>`).join('')}</div>` : ''}`;
  if ($('#rph', el)) $('#rph', el).onclick = () => viewImage('/img/' + r.photo_id);
  const act = (body) => api('POST', `/requests/${r.no}/action`, body).then(() => { toast(t('تم الحفظ')); route(true); });
  $$('[data-a]', el).forEach((b) => (b.onclick = () => {
    const a = b.dataset.a;
    if (a === 'start') return busy(b, () => act({ action: 'start' }));
    if (a === 'fix') {
      return sheet(`<h2>${t('تم الإصلاح')}</h2>
        <div class="field"><label class="f req">${t('ما الذي تم إصلاحه؟')}</label><textarea class="in" id="n" maxlength="1000" placeholder="${t('مثال: تم تغيير كابل الشاشة')}"></textarea></div>
        <div class="field"><label class="f">${t('حالة الجهاز بعد الإصلاح')}</label>${statusSeg('ok', ['ok', 'out'])}</div>
        ${otherOpen ? `<label class="toggle"><span>${t('أغلق أيضاً {n} بلاغ آخر مفتوح على هذا الجهاز', { n: otherOpen })}</span><input type="checkbox" id="all" checked></label>` : ''}
        <div class="grid2" style="margin-top:12px"><button class="btn ok" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
      (sh, close) => {
        bindSeg(sh);
        $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
          await act({ action: 'fix', note: $('#n', sh).value, status: segVal(sh), all: !!$('#all', sh)?.checked });
          close();
        });
      });
    }
    if (a === 'close') {
      const reasons = ['لا يوجد عطل', 'بلاغ مكرر', 'مشكلة في طريقة الاستخدام', 'يحتاج قطعة غير متوفرة'];
      return sheet(`<h2>${t('إغلاق بدون إصلاح')}</h2>
        <div class="chips" style="margin-bottom:10px">${reasons.map((x) => `<button class="chip sm" data-r="${esc(t(x))}">${t(x)}</button>`).join('')}</div>
        <div class="field"><label class="f req">${t('سبب الإغلاق')}</label><textarea class="in" id="n" maxlength="1000"></textarea></div>
        <div class="grid2"><button class="btn primary" id="ok">${t('إغلاق البلاغ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
      (sh, close) => {
        $$('[data-r]', sh).forEach((c) => (c.onclick = () => { $('#n', sh).value = c.dataset.r; }));
        $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => { await act({ action: 'close', note: $('#n', sh).value }); close(); });
      });
    }
    if (a === 'reopen') return busy(b, () => act({ action: 'reopen' }));
    if (a === 'note') return noteSheet((note) => act({ action: 'note', note }));
  }));
}

function noteSheet(save) {
  sheet(`<h2>${t('إضافة ملاحظة')}</h2>
    <div class="field"><textarea class="in" id="n" maxlength="1000" placeholder="${t('ملاحظة للمهندس القادم…')}"></textarea></div>
    <div class="grid2"><button class="btn primary" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    $('#n', sh).focus();
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => { await save($('#n', sh).value); close(); });
  });
}

const statusSeg = (cur, keys = Object.keys(STATUS)) =>
  `<div class="seg" data-seg>${keys.map((k) => `<button type="button" data-v="${k}" class="${k === cur ? 'on' : ''}">${t(STATUS[k])}</button>`).join('')}</div>`;
function bindSeg(root, onChange) {
  $$('[data-seg] button', root).forEach((b) => (b.onclick = () => {
    $$('button', b.parentElement).forEach((x) => x.classList.toggle('on', x === b));
    onChange?.(b.dataset.v);
  }));
}
const segVal = (root) => $('[data-seg] button.on', root)?.dataset.v;

function timeline(log) {
  if (!log.length) return `<div class="muted">${t('لا يوجد سجل بعد')}</div>`;
  return `<ul class="tl">${log.map((g) => `<li class="k-${esc(g.kind)} s-${esc(g.status || '')}">
    <div class="what">${t(LOG_KIND[g.kind] || g.kind)}${g.status ? ' ' + stBadge(g.status) : ''}${g.damage ? ` <span class="badge">${dmg(g.damage)}</span>` : ''}
      ${g.request_no ? `<a class="small mono" href="#/req/${g.request_no}">#${g.request_no}</a>` : ''}</div>
    <div class="when">${fmtTime(g.ts)} · ${esc(g.user || '')}</div>
    ${g.note ? `<div class="note">${esc(t(g.note))}</div>` : ''}</li>`).join('')}</ul>`;
}

// ---------- labs
async function tLabs(el) {
  const { labs } = await api('GET', '/labs');
  el.innerHTML = `<div class="sec-h" style="margin-top:4px"><h1 style="margin:0">${t('المعامل')}</h1>
      ${S.isAdmin ? `<button class="btn primary sm" id="add">${ICON.plus}${t('إضافة معمل')}</button>` : ''}</div>
    ${labs.length ? `<div class="list">${labs.map((l) => `<a class="card labcard" style="margin:0" href="#/lab/${l.id}">
      <div class="hd"><span class="li-ic">${ICON.lab}</span><div style="flex:1;min-width:0"><b style="font-size:17px">${esc(labName(l))}</b> <span class="mono muted small">${esc(l.code)}</span>
        <div class="muted small">${l.location ? esc(l.location) + ' · ' : ''}${t('{n} جهاز', { n: l.total })}</div></div>
        ${(l.needs_fix || 0) + (l.in_repair || 0) ? `<span class="badge st-needs_fix">${t('{n} معطّل', { n: (l.needs_fix || 0) + (l.in_repair || 0) })}</span>` : l.total ? `<span class="badge st-ok">${t('كلها تعمل')}</span>` : ''}</div>
      ${labBar(l)}</a>`).join('')}</div>${legend()}`
      : `<div class="empty">${t('لم تُضف أي معامل بعد')}${S.isAdmin ? '' : `<div class="small">${t('مدير النظام يضيف المعامل والأجهزة')}</div>`}</div>`}`;
  if ($('#add', el)) $('#add', el).onclick = () => labSheet(null);
}

function labSheet(lab) {
  sheet(`<h2>${lab ? t('تعديل المعمل') : t('إضافة معمل')}</h2>
    <div class="field"><label class="f req">${t('اسم المعمل')}</label><input class="in" id="nm" maxlength="80" value="${esc(lab?.name || '')}" placeholder="${t('مثال: معمل الحاسب 1')}"></div>
    <div class="field"><label class="f">${t('الاسم بالإنجليزية (اختياري)')}</label><input class="in" id="ne" maxlength="80" dir="ltr" value="${esc(lab?.name_en || '')}" placeholder="Computer Lab 1"></div>
    <div class="grid2">
      <div class="field"><label class="f req">${t('رمز المعمل')}</label><input class="in mono" id="cd" maxlength="8" value="${esc(lab?.code || '')}" placeholder="LAB1" style="text-transform:uppercase"></div>
      <div class="field"><label class="f">${t('المكان')}</label><input class="in" id="lc" maxlength="120" value="${esc(lab?.location || '')}" placeholder="${t('مثال: الدور الأول')}"></div>
    </div>
    <div class="muted small" style="margin:-4px 0 10px">${t('الرمز يظهر في أرقام الأجهزة، مثل LAB1-01')}</div>
    <div class="field"><label class="f">${t('ملاحظات')}</label><textarea class="in" id="no" maxlength="500">${esc(lab?.notes || '')}</textarea></div>
    <div class="grid2"><button class="btn primary" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    $('#nm', sh).focus();
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
      const body = { name: $('#nm', sh).value, name_en: $('#ne', sh).value, code: $('#cd', sh).value, location: $('#lc', sh).value, notes: $('#no', sh).value };
      if (lab) await api('PATCH', '/labs/' + lab.id, body);
      else { const r = await api('POST', '/labs', body); close(); location.hash = '#/lab/' + r.id; return; }
      close(); toast(t('تم الحفظ')); route(true);
    });
  });
}

async function tLab(el, id, filter) {
  const { lab, devices } = await api('GET', '/labs/' + id);
  const cnt = Object.fromEntries(Object.keys(STATUS).map((k) => [k, devices.filter((d) => d.status === k).length]));
  const shown = filter === 'all' ? devices : filter === 'broken' ? devices.filter((d) => ['needs_fix', 'in_repair'].includes(d.status)) : devices.filter((d) => d.status === filter);
  const tabs = [['all', 'الكل', devices.length], ['broken', 'معطّل', cnt.needs_fix + cnt.in_repair], ['ok', STATUS.ok, cnt.ok], ['out', STATUS.out, cnt.out]];
  el.innerHTML = `<div class="crumbs"><a href="#/labs">${LANG === 'en' ? '←' : '→'} ${t('المعامل')}</a></div>
    <div class="row" style="margin-bottom:6px"><h1 class="grow" style="margin:0">${esc(labName(lab))} <span class="mono muted" style="font-size:15px">${esc(lab.code)}</span></h1></div>
    ${lab.location || lab.notes ? `<div class="muted" style="margin-bottom:10px">${esc([lab.location, lab.notes].filter(Boolean).join(' · '))}</div>` : ''}
    <div class="actrow" style="margin-bottom:12px">
      ${S.isAdmin ? `<button class="btn primary" id="addd">${ICON.plus}${t('إضافة أجهزة')}</button>` : ''}
      <a class="btn" href="#/labels/${lab.id}">${ICON.qr}${t('ملصقات QR')}</a>
      ${S.isAdmin ? `<button class="btn" id="edit">${ICON.edit}${t('تعديل المعمل')}</button>` : ''}
    </div>
    <div class="tabs">${tabs.map(([k, l, n]) => `<button class="${k === filter ? 'on' : ''}" data-t="${k}">${t(l)}<span class="n">${n}</span></button>`).join('')}</div>
    ${shown.length ? `<div class="dgrid">${shown.map((d) => `<a class="dtile st-${esc(d.status)}" href="#/dev/${d.id}">
      ${d.open_reqs ? `<span class="flag" title="${t('بلاغات مفتوحة')}">${d.open_reqs}</span>` : ''}
      <span class="ic">${typeIc(d.type)}</span><b>${esc(d.name)}</b><span class="mono">${esc(d.code)}</span>${stBadge(d.status)}
      ${d.damage && d.status !== 'ok' ? `<span class="small muted">${dmg(d.damage)}</span>` : ''}</a>`).join('')}</div>`
      : `<div class="empty">${devices.length ? t('لا توجد أجهزة بهذه الحالة') : t('لا توجد أجهزة في هذا المعمل')}</div>`}
    ${S.isAdmin ? `<div class="dangerzone"><button class="btn sm danger" id="del">${t('حذف المعمل')}</button></div>` : ''}`;
  $$('.tabs button', el).forEach((b) => (b.onclick = () => { location.hash = `#/lab/${id}/${b.dataset.t}`; }));
  if (!S.isAdmin) return;
  $('#edit', el).onclick = () => labSheet(lab);
  $('#addd', el).onclick = () => addDevicesSheet(lab);
  $('#del', el).onclick = () => sheet(`<h2>${t('حذف المعمل')}</h2>
    <div class="alert bad" style="margin-bottom:12px">${t('سيُحذف المعمل و{n} جهاز مع كل البلاغات والسجلات. لا يمكن التراجع.', { n: devices.length })}</div>
    <div class="field"><label class="f">${t('اكتب رمز المعمل للتأكيد:')} <b class="mono">${esc(lab.code)}</b></label><input class="in mono" id="cf" autocomplete="off"></div>
    <div class="grid2"><button class="btn btn-red" id="ok" disabled>${t('حذف نهائي')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    $('#cf', sh).oninput = (e) => { $('#ok', sh).disabled = e.target.value.trim().toUpperCase() !== lab.code; };
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => { await api('DELETE', '/labs/' + lab.id); close(); toast(t('تم الحذف')); location.hash = '#/labs'; });
  });
}

function typeSelect(cur) {
  return `<select class="in" id="ty">${Object.keys(TYPES).map((k) => `<option value="${k}" ${k === cur ? 'selected' : ''}>${typeName(k)}</option>`).join('')}</select>`;
}

function addDevicesSheet(lab) {
  sheet(`<h2>${t('إضافة أجهزة إلى')} ${esc(labName(lab))}</h2>
    <div class="grid2">
      <div class="field"><label class="f">${t('نوع الجهاز')}</label>${typeSelect('pc')}</div>
      <div class="field"><label class="f">${t('العدد')}</label><input class="in" id="ct" type="number" min="1" max="60" value="1" inputmode="numeric"></div>
    </div>
    <div class="field"><label class="f">${t('اسم الجهاز')}</label><input class="in" id="nm" maxlength="60" placeholder="${t('مثال: جهاز الطالب')}">
      <div class="muted small" id="hint" style="margin-top:4px"></div></div>
    <div class="grid2">
      <div class="field"><label class="f">${t('الشركة المصنّعة')}</label><input class="in" id="br" maxlength="60" placeholder="Dell"></div>
      <div class="field"><label class="f">${t('الموديل')}</label><input class="in" id="md" maxlength="60" placeholder="OptiPlex 7090"></div>
    </div>
    <div class="field" id="snf"><label class="f">${t('الرقم التسلسلي')}</label><input class="in mono" id="sn" maxlength="60"></div>
    <div class="grid2"><button class="btn primary" id="ok">${t('إضافة')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    const upd = () => {
      const n = Math.max(1, parseInt($('#ct', sh).value, 10) || 1), nm = $('#nm', sh).value.trim() || typeName($('#ty', sh).value);
      $('#snf', sh).classList.toggle('hidden', n > 1);
      $('#hint', sh).textContent = n > 1 ? t('ستُسمّى: {a} 1، {a} 2 … {a} {n}', { a: nm, n }) : '';
    };
    $('#ct', sh).oninput = upd; $('#nm', sh).oninput = upd; $('#ty', sh).onchange = upd; upd();
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
      const ty = $('#ty', sh).value;
      const r = await api('POST', `/labs/${lab.id}/devices`, { type: ty, count: $('#ct', sh).value, name: $('#nm', sh).value.trim() || typeName(ty),
        brand: $('#br', sh).value, model: $('#md', sh).value, serial: $('#sn', sh).value });
      close(); toast(t('أُضيف {n} جهاز', { n: r.ids.length })); route(true);
    });
  });
}

// ---------- device page: status, last maintenance, previous problems, engineers' notes
async function tDevice(el, id, tab) {
  const { device: d, log, requests } = await api('GET', '/devices/' + id);
  const dlab = { name: d.lab_name, name_en: d.lab_name_en };
  const open = requests.filter((r) => ['new', 'progress'].includes(r.status));
  const notes = log.filter((g) => ['note', 'maint', 'req_done', 'req_closed'].includes(g.kind) && g.note);
  const tabs = [['log', 'السجل الكامل', log.length], ['problems', 'المشاكل السابقة', requests.length], ['notes', 'ملاحظات المهندسين', notes.length]];
  el.innerHTML = `<div class="crumbs"><a href="#/lab/${d.lab_id}">${LANG === 'en' ? '←' : '→'} ${esc(labName(dlab))}</a></div>
    <div class="card">
      <div class="row"><span style="width:54px;height:54px;border-radius:15px;background:var(--primary-soft);color:var(--primary);display:grid;place-items:center;flex:none">${typeIc(d.type)}</span>
        <div class="grow"><h1 style="margin:0">${esc(d.name)}</h1><div class="muted"><span class="mono">${esc(d.code)}</span> · ${typeName(d.type)}</div></div>
        <span style="font-size:15px">${stBadge(d.status)}</span></div>
      <dl class="kv" style="margin-top:14px">
        <dt>${t('الحالة')}</dt><dd>${stBadge(d.status)}${d.damage && d.status !== 'ok' ? ` <b>${dmg(d.damage)}</b>` : ''}</dd>
        ${d.damage_note && d.status !== 'ok' ? `<dt>${t('وصف العطل')}</dt><dd>${esc(d.damage_note)}</dd>` : ''}
        <dt>${t('آخر صيانة')}</dt><dd>${d.last_maint_at ? `${fmtTime(d.last_maint_at, false)} · ${esc(d.last_maint_by || '')} <span class="muted small">(${ago(d.last_maint_at)})</span>` : t('لم تُسجّل صيانة بعد')}</dd>
        <dt>${t('بلاغات مفتوحة')}</dt><dd>${open.length ? open.map((r) => `<a href="#/req/${r.no}" class="mono">#${r.no}</a>`).join(' ') : '0'}</dd>
      </dl>
    </div>
    <div class="actrow" style="margin-bottom:12px">
      <button class="btn primary" id="st">${ICON.alert}${t('تغيير الحالة')}</button>
      <button class="btn ok" id="mt">${ICON.wrench}${t('تسجيل صيانة')}</button>
      <button class="btn" id="nt">${ICON.note}${t('إضافة ملاحظة')}</button>
    </div>
    <details class="card more"><summary>${t('بيانات الجهاز')}</summary>
      <dl class="kv" style="margin-top:8px">
        <dt>${t('المعمل')}</dt><dd>${esc(labName(dlab))}</dd>
        <dt>${t('الشركة المصنّعة')}</dt><dd>${esc(d.brand || '—')}</dd>
        <dt>${t('الموديل')}</dt><dd>${esc(d.model || '—')}</dd>
        <dt>${t('الرقم التسلسلي')}</dt><dd class="mono">${esc(d.serial || '—')}</dd>
        <dt>${t('أُضيف')}</dt><dd>${fmtTime(d.created_at, false)}</dd>
        ${d.notes ? `<dt>${t('ملاحظات')}</dt><dd style="white-space:pre-wrap">${esc(d.notes)}</dd>` : ''}
      </dl>
      ${S.isAdmin ? `<div class="row" style="margin-top:12px"><button class="btn sm" id="ed">${ICON.edit}${t('تعديل البيانات')}</button><button class="btn sm danger" id="del">${t('حذف الجهاز')}</button></div>` : ''}
    </details>
    <div class="tabs">${tabs.map(([k, l, n]) => `<button class="${k === tab ? 'on' : ''}" data-t="${k}">${t(l)}<span class="n">${n}</span></button>`).join('')}</div>
    <div class="card" id="tabc"></div>`;
  const tc = $('#tabc', el);
  if (tab === 'problems') {
    tc.innerHTML = requests.length ? `<div class="list">${requests.map((r) => `<a class="li" href="#/req/${r.no}" style="border:0;border-bottom:1px solid var(--line);border-radius:0;padding:10px 0">
      <span class="body"><span class="t">#${r.no} · ${dmg(r.problem)}</span>
      <span class="s">${fmtTime(r.created_at, false)}${r.closed_by ? ' · ' + esc(r.closed_by) : ''}</span>
      ${r.description ? `<span class="s" style="display:block">${esc(r.description)}</span>` : ''}
      ${r.resolution ? `<span class="s" style="display:block;color:var(--ok)">✓ ${esc(r.resolution)}</span>` : ''}</span>${rqBadge(r.status)}</a>`).join('')}</div>`
      : `<div class="muted">${t('لا توجد مشاكل سابقة لهذا الجهاز')}</div>`;
  } else tc.innerHTML = timeline(tab === 'notes' ? notes : log);
  $$('.tabs button', el).forEach((b) => (b.onclick = () => { location.hash = `#/dev/${id}/${b.dataset.t}`; }));

  $('#st', el).onclick = () => sheet(`<h2>${t('تغيير حالة الجهاز')}</h2>
    <div class="field">${statusSeg(d.status)}</div>
    <div id="dmgbox"><label class="f req">${t('نوع العطل')}</label>
      <div class="chips" id="dk" style="margin-bottom:12px">${Object.keys(DAMAGE).map((k) => `<button type="button" class="chip sm ${k === d.damage ? 'on' : ''}" data-k="${k}">${dmg(k)}</button>`).join('')}</div></div>
    <div class="field"><label class="f">${t('ملاحظة')}</label><textarea class="in" id="n" maxlength="1000"></textarea></div>
    <div class="grid2"><button class="btn primary" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    let dk = d.damage || '';
    const showDmg = (v) => $('#dmgbox', sh).classList.toggle('hidden', v === 'ok');
    bindSeg(sh, showDmg); showDmg(d.status);
    $$('#dk .chip', sh).forEach((c) => (c.onclick = () => { dk = c.dataset.k; $$('#dk .chip', sh).forEach((x) => x.classList.toggle('on', x === c)); }));
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
      const status = segVal(sh);
      if (status !== 'ok' && !dk) { toast(t('اختر نوع العطل'), true); return; }
      await api('POST', `/devices/${d.id}/status`, { status, damage: dk, note: $('#n', sh).value });
      close(); toast(t('تم الحفظ')); route(true);
    });
  });
  $('#mt', el).onclick = () => sheet(`<h2>${t('تسجيل صيانة')}</h2>
    <div class="field"><label class="f req">${t('ما الذي تم عمله؟')}</label><textarea class="in" id="n" maxlength="1000" placeholder="${t('مثال: تنظيف الجهاز وتحديث النظام')}"></textarea></div>
    <div class="field"><label class="f">${t('حالة الجهاز بعد الصيانة')}</label>${statusSeg('ok')}</div>
    ${open.length ? `<label class="toggle"><span>${t('أغلق {n} بلاغ مفتوح على هذا الجهاز (تم الإصلاح)', { n: open.length })}</span><input type="checkbox" id="cr" checked></label>` : ''}
    <div class="grid2" style="margin-top:12px"><button class="btn ok" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
  (sh, close) => {
    bindSeg(sh, (v) => { const c = $('#cr', sh); if (c) { c.checked = v === 'ok'; c.disabled = v !== 'ok'; } });
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
      await api('POST', `/devices/${d.id}/maint`, { note: $('#n', sh).value, status: segVal(sh), close_reqs: !!$('#cr', sh)?.checked });
      close(); toast(t('تم الحفظ')); route(true);
    });
  });
  $('#nt', el).onclick = () => noteSheet((note) => api('POST', `/devices/${d.id}/note`, { note }).then(() => { toast(t('تم الحفظ')); location.hash = `#/dev/${d.id}/notes`; route(true); }));
  if (!S.isAdmin) return;
  $('#ed', el).onclick = async () => {
    const { labs } = await api('GET', '/labs');
    sheet(`<h2>${t('تعديل البيانات')}</h2>
      <div class="grid2">
        <div class="field"><label class="f">${t('اسم الجهاز')}</label><input class="in" id="nm" maxlength="60" value="${esc(d.name)}"></div>
        <div class="field"><label class="f">${t('رقم الجهاز')}</label><input class="in mono" id="cd" maxlength="26" value="${esc(d.code)}" style="text-transform:uppercase"></div>
      </div>
      <div class="grid2">
        <div class="field"><label class="f">${t('نوع الجهاز')}</label>${typeSelect(d.type)}</div>
        <div class="field"><label class="f">${t('المعمل')}</label><select class="in" id="lb">${labs.map((l) => `<option value="${l.id}" ${l.id === d.lab_id ? 'selected' : ''}>${esc(labName(l))}</option>`).join('')}</select></div>
      </div>
      <div class="grid2">
        <div class="field"><label class="f">${t('الشركة المصنّعة')}</label><input class="in" id="br" maxlength="60" value="${esc(d.brand || '')}"></div>
        <div class="field"><label class="f">${t('الموديل')}</label><input class="in" id="md" maxlength="60" value="${esc(d.model || '')}"></div>
      </div>
      <div class="field"><label class="f">${t('الرقم التسلسلي')}</label><input class="in mono" id="sn" maxlength="60" value="${esc(d.serial || '')}"></div>
      <div class="field"><label class="f">${t('ملاحظات')}</label><textarea class="in" id="no" maxlength="500">${esc(d.notes || '')}</textarea></div>
      <div class="grid2"><button class="btn primary" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
    (sh, close) => {
      $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
        await api('PATCH', '/devices/' + d.id, { name: $('#nm', sh).value, code: $('#cd', sh).value, type: $('#ty', sh).value, lab_id: $('#lb', sh).value,
          brand: $('#br', sh).value, model: $('#md', sh).value, serial: $('#sn', sh).value, notes: $('#no', sh).value });
        close(); toast(t('تم الحفظ')); route(true);
      });
    });
  };
  $('#del', el).onclick = async () => {
    if (!(await confirmDlg(t('حذف الجهاز {c} مع سجله وبلاغاته؟', { c: d.code }), t('حذف نهائي'), true))) return;
    await api('DELETE', '/devices/' + d.id); toast(t('تم الحذف')); location.hash = '#/lab/' + d.lab_id;
  };
}

// ---------- printable QR labels: one poster for the lab door + one sticker per device
async function tLabels(el, id) {
  const { lab, devices } = await api('GET', '/labs/' + id);
  const base = location.origin;
  el.innerHTML = `<div class="noprint"><div class="crumbs"><a href="#/lab/${lab.id}">${LANG === 'en' ? '←' : '→'} ${esc(labName(lab))}</a></div>
      <div class="sec-h" style="margin-top:0"><h1 style="margin:0">${t('ملصقات QR')}</h1><button class="btn primary" id="pr">${ICON.print}${t('طباعة')}</button></div>
      <div class="muted" style="margin-bottom:12px">${t('ألصق ملصق كل جهاز عليه، وضع ملصق المعمل على الباب. الطالب يمسح الرمز بجواله ليبلّغ مباشرة.')}</div></div>
    <div class="qposter"><h2>${t('عطل في جهاز؟ امسح الرمز')}</h2>${qrSvg(`${base}/l/${lab.code}`)}
      <b style="font-size:18px">${esc(labName(lab))}</b><div class="mono" style="color:#586079">${esc(base.replace(/^https?:\/\//, ''))}</div></div>
    <div class="labels">${devices.map((d) => `<div class="qlabel">${qrSvg(`${base}/d/${d.code}`)}<div class="c">${esc(d.code)}</div>
      <div class="n">${esc(d.name)}</div><div class="h">${t('امسح للإبلاغ عن مشكلة')}</div></div>`).join('')}</div>`;
  $('#pr', el).onclick = () => window.print();
}

// ---------- menu, users, password, about
function tMenu(el) {
  const it = (href, ic, label, id = '') => `<a href="${href}" ${id ? `id="${id}"` : ''}>${ICON[ic]}<span>${label}</span></a>`;
  el.innerHTML = `<div class="card"><div class="row"><span class="logo-lg" style="width:48px;height:48px;margin:0">${ICON.users}</span>
      <div class="grow"><b style="font-size:17px">${esc(S.user.name)}</b><div class="muted small"><span class="mono">${esc(S.user.username)}</span> · ${S.isAdmin ? t('مدير النظام') : t('فريق الصيانة')}</div></div></div></div>
    <div class="card menu-list" style="padding:0 14px">
      ${S.isAdmin ? it('#/users', 'users', t('المستخدمون وكلمات المرور')) : ''}
      ${it('#/password', 'key', t('تغيير كلمة المرور'))}
      ${it('#/about', 'info', t('عن المشروع'))}
      ${it('#/menu', 'xls', t('تصدير إلى Excel'), 'exp')}
      ${it('/', 'alert', t('صفحة بلاغات الطلاب'))}
      <button id="lo" style="color:var(--bad)">${ICON.out.replace('<svg', '<svg style="color:var(--bad)"')}<span>${t('تسجيل الخروج')}</span></button>
    </div>`;
  $('#lo', el).onclick = () => logout();
  $('#exp', el).onclick = (e) => { e.preventDefault(); exportCsv(); };
}

async function exportCsv() {
  try {
    const { devices, requests, logs } = await api('GET', '/export');
    const day = new Date().toISOString().slice(0, 10);
    downloadCsv(`lab-devices-${day}.csv`, [
      [t('رقم الجهاز'), t('اسم الجهاز'), t('نوع الجهاز'), t('المعمل'), t('الحالة'), t('نوع العطل'), t('وصف العطل'), t('آخر صيانة'), t('بواسطة'), t('الشركة المصنّعة'), t('الموديل'), t('الرقم التسلسلي'), t('ملاحظات')],
      ...devices.map((d) => [d.code, d.name, typeName(d.type), d.lab_name, t(STATUS[d.status]), dmg(d.damage), d.damage_note, csvTime(d.last_maint_at), d.last_maint_by, d.brand, d.model, d.serial, d.notes]),
    ]);
    downloadCsv(`lab-requests-${day}.csv`, [
      [t('رقم البلاغ'), t('التاريخ'), t('رقم الجهاز'), t('المعمل'), t('المشكلة'), t('الوصف'), t('المُبلّغ'), t('الصف / الفصل'), t('الحالة'), t('المسؤول'), t('أُغلق'), t('ما تم إصلاحه')],
      ...requests.map((r) => [r.no, csvTime(r.created_at), r.device_code, r.lab_name, dmg(r.problem), r.description, r.reporter, r.grade, t(REQ_STATUS[r.status]), r.assigned_name, csvTime(r.closed_at), r.resolution]),
    ]);
    downloadCsv(`lab-log-${day}.csv`, [
      [t('التاريخ'), t('رقم الجهاز'), t('الحدث'), t('الحالة'), t('نوع العطل'), t('ملاحظة'), t('بواسطة'), t('رقم البلاغ')],
      ...logs.map((g) => [csvTime(g.ts), g.device_code, t(LOG_KIND[g.kind] || g.kind), g.status ? t(STATUS[g.status]) : '', dmg(g.damage), g.note, g.user, g.request_no]),
    ]);
    toast(t('تم تنزيل 3 ملفات'));
  } catch (e) { toast(e.message, true); }
}

async function tUsers(el) {
  if (!S.isAdmin) { location.hash = '#/menu'; return; }
  const { users } = await api('GET', '/users');
  el.innerHTML = `<div class="crumbs"><a href="#/menu">${LANG === 'en' ? '←' : '→'} ${t('القائمة')}</a></div>
    <div class="sec-h" style="margin-top:0"><h1 style="margin:0">${t('المستخدمون')}</h1><button class="btn primary sm" id="add">${ICON.plus}${t('مستخدم جديد')}</button></div>
    <div class="list">${users.map((u) => `<button class="li" data-u="${u.id}" style="text-align:start;font:inherit;width:100%">
      <span class="th">${ICON.users}</span>
      <span class="body"><span class="t">${esc(u.name)} ${u.id === S.user.id ? `<span class="muted small">(${t('أنت')})</span>` : ''}</span>
        <span class="s"><span class="mono">${esc(u.username)}</span> · ${t('آخر دخول')}: ${u.last_login ? ago(u.last_login) : '—'}</span></span>
      <span style="display:grid;gap:4px;justify-items:end"><span class="badge ${u.role === 'admin' ? 'rq-new' : ''}">${u.role === 'admin' ? t('مدير') : t('فني صيانة')}</span>
        ${u.active ? '' : `<span class="badge st-out">${t('موقوف')}</span>`}</span></button>`).join('')}</div>
    <div class="muted small" style="margin-top:12px">${t('المدير يضيف المعامل والأجهزة والمستخدمين. فني الصيانة يستلم البلاغات ويحدّث حالة الأجهزة.')}</div>`;
  $('#add', el).onclick = () => userSheet(null);
  $$('[data-u]', el).forEach((b) => (b.onclick = () => userSheet(users.find((u) => u.id === b.dataset.u))));
}

function userSheet(u) {
  const roleSeg = (cur) => `<div class="seg" data-role>${[['tech', 'فني صيانة'], ['admin', 'مدير']].map(([k, l]) => `<button type="button" data-v="${k}" class="${k === cur ? 'on' : ''}">${t(l)}</button>`).join('')}</div>`;
  sheet(`<h2>${u ? esc(u.name) : t('مستخدم جديد')}</h2>
    <div class="grid2">
      <div class="field"><label class="f req">${t('الاسم')}</label><input class="in" id="nm" maxlength="60" value="${esc(u?.name || '')}"></div>
      <div class="field"><label class="f req">${t('اسم المستخدم')}</label><input class="in" id="un" maxlength="30" dir="ltr" autocapitalize="none" value="${esc(u?.username || '')}" placeholder="ahmed"></div>
    </div>
    <div class="field"><label class="f">${t('الصلاحية')}</label>${roleSeg(u?.role || 'tech')}</div>
    <div class="field"><label class="f ${u ? '' : 'req'}">${u ? t('إعادة تعيين كلمة المرور') : t('كلمة المرور')}</label>${pwField('pw', u ? t('اتركها فارغة لعدم التغيير') : '', 'new-password')}</div>
    ${u && u.id !== S.user.id ? `<label class="toggle"><span>${t('الحساب مفعّل')}</span><input type="checkbox" id="ac" ${u.active ? 'checked' : ''}></label>` : ''}
    <div class="grid2" style="margin-top:12px"><button class="btn primary" id="ok">${t('حفظ')}</button><button class="btn" data-close>${t('إلغاء')}</button></div>
    ${u && u.id !== S.user.id ? `<div class="dangerzone"><button class="btn sm danger" id="del">${t('حذف المستخدم')}</button></div>` : ''}`,
  (sh, close) => {
    bindEyes(sh);
    $$('[data-role] button', sh).forEach((b) => (b.onclick = () => $$('[data-role] button', sh).forEach((x) => x.classList.toggle('on', x === b))));
    $('#ok', sh).onclick = (e) => busy(e.currentTarget, async () => {
      const body = { name: $('#nm', sh).value, username: $('#un', sh).value, role: $('[data-role] button.on', sh).dataset.v };
      const pw = $('#pw', sh).value;
      if (u) {
        if (pw) body.password = pw;
        if ($('#ac', sh)) body.active = $('#ac', sh).checked;
        await api('PATCH', '/users/' + u.id, body);
        if (u.id === S.user.id) { S.user = { ...S.user, name: body.name || S.user.name, username: body.username.toLowerCase(), role: body.role }; LS.set('user', S.user); renderHeader(); }
      } else {
        body.password = pw;
        await api('POST', '/users', body);
      }
      close(); toast(pw && u ? t('تم تعيين كلمة المرور الجديدة') : t('تم الحفظ')); route(true);
    });
    if ($('#del', sh)) $('#del', sh).onclick = async () => {
      close();
      if (!(await confirmDlg(t('حذف المستخدم {n}؟', { n: u.name }), t('حذف'), true))) return;
      try { await api('DELETE', '/users/' + u.id); toast(t('تم الحذف')); route(true); } catch (er) { toast(er.message, true); }
    };
  });
}

function tPassword(el) {
  el.innerHTML = `<div class="crumbs"><a href="#/menu">${LANG === 'en' ? '←' : '→'} ${t('القائمة')}</a></div>
    <h1>${t('تغيير كلمة المرور')}</h1>
    <div class="card">
      <div class="field"><label class="f">${t('كلمة المرور الحالية')}</label>${pwField('c')}</div>
      <div class="field"><label class="f">${t('كلمة المرور الجديدة')}</label>${pwField('n', '', 'new-password')}</div>
      <div class="field"><label class="f">${t('أعد كتابة كلمة المرور الجديدة')}</label>${pwField('n2', '', 'new-password')}</div>
      <button class="btn primary big" id="ok">${t('حفظ')}</button>
    </div>`;
  bindEyes(el);
  $('#ok', el).onclick = (e) => busy(e.currentTarget, async () => {
    if ($('#n', el).value !== $('#n2', el).value) { toast(t('كلمتا المرور غير متطابقتين'), true); return; }
    await api('POST', '/me/password', { current: $('#c', el).value, password: $('#n', el).value });
    toast(t('تم تغيير كلمة المرور')); location.hash = '#/menu';
  });
}

async function tAbout(el) {
  const { about } = await api('GET', '/pub/about');
  el.innerHTML = `<div class="crumbs"><a href="#/menu">${LANG === 'en' ? '←' : '→'} ${t('القائمة')}</a></div>
    ${S.isAdmin ? `<div style="margin-bottom:10px"><a class="btn primary block" href="#/about-edit">${ICON.edit}${t('تعديل صفحة «عن المشروع»')}</a></div>` : ''}
    ${aboutHtml(about)}`;
}

async function tAboutEdit(el) {
  if (!S.isAdmin) { location.hash = '#/about'; return; }
  const { about: a } = await api('GET', '/pub/about');
  const rows = (a.students || []).length ? a.students : [{ name: '', role: '' }];
  const row = (s) => `<div class="strow"><input class="in" data-sn maxlength="80" value="${esc(s.name || '')}" placeholder="${t('اسم الطالب')}">
    <input class="in" data-sr maxlength="80" value="${esc(s.role || '')}" placeholder="${t('الدور (اختياري)')}"><button class="iconbtn" data-x aria-label="${t('حذف')}">✕</button></div>`;
  el.innerHTML = `<div class="crumbs"><a href="#/about">${LANG === 'en' ? '←' : '→'} ${t('عن المشروع')}</a></div>
    <h1>${t('تعديل صفحة «عن المشروع»')}</h1>
    <div class="card">
      <h3 style="margin-top:0">${t('فريق العمل من الطلاب')}</h3>
      <div id="sts">${rows.map(row).join('')}</div>
      <button class="btn sm" id="addst">${ICON.plus}${t('إضافة طالب')}</button>
    </div>
    <div class="card">
      <div class="grid2">
        <div class="field"><label class="f">${t('اسم المشروع')}</label><input class="in" id="ti" maxlength="120" value="${esc(a.title || '')}" placeholder="${t('نظام صيانة أجهزة المعامل')}"></div>
        <div class="field"><label class="f">${t('اسم المشروع بالإنجليزية')}</label><input class="in" id="tie" dir="ltr" maxlength="120" value="${esc(a.title_en || '')}" placeholder="Lab Maintenance System"></div>
        <div class="field"><label class="f">${t('اسم المدرسة')}</label><input class="in" id="sc" maxlength="120" value="${esc(a.school || '')}"></div>
        <div class="field"><label class="f">${t('اسم المدرسة بالإنجليزية')}</label><input class="in" id="sce" dir="ltr" maxlength="120" value="${esc(a.school_en || '')}"></div>
        <div class="field"><label class="f">${t('المعلم المشرف')}</label><input class="in" id="sv" maxlength="120" value="${esc(a.supervisor || '')}"></div>
        <div class="field"><label class="f">${t('العام الدراسي')}</label><input class="in" id="yr" maxlength="30" value="${esc(a.year || '')}" placeholder="2026"></div>
      </div>
      <div class="field"><label class="f">${t('نبذة عن المشروع')}</label><textarea class="in" id="de" maxlength="2000">${esc(a.description || '')}</textarea></div>
      <div class="field"><label class="f">${t('النبذة بالإنجليزية')}</label><textarea class="in" id="dee" dir="ltr" maxlength="2000">${esc(a.description_en || '')}</textarea></div>
    </div>
    <button class="btn primary big" id="save">${t('حفظ')}</button>`;
  const bindX = () => $$('[data-x]', el).forEach((b) => (b.onclick = () => { b.parentElement.remove(); if (!$('#sts .strow', el)) $('#sts', el).insertAdjacentHTML('beforeend', row({})); bindX(); }));
  bindX();
  $('#addst', el).onclick = () => { $('#sts', el).insertAdjacentHTML('beforeend', row({})); bindX(); $$('#sts [data-sn]', el).pop().focus(); };
  $('#save', el).onclick = (e) => busy(e.currentTarget, async () => {
    const students = $$('#sts .strow', el).map((r) => ({ name: $('[data-sn]', r).value, role: $('[data-sr]', r).value })).filter((s) => s.name.trim());
    await api('PUT', '/about', { students, title: $('#ti', el).value, title_en: $('#tie', el).value, school: $('#sc', el).value, school_en: $('#sce', el).value,
      supervisor: $('#sv', el).value, year: $('#yr', el).value, description: $('#de', el).value, description_en: $('#dee', el).value });
    toast(t('تم الحفظ')); location.hash = '#/about';
  });
}

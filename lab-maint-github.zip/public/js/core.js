// Shared state, API client, UI helpers, reference lists, theme + language.
'use strict';

const LS = {
  get(k, d) { try { const v = localStorage.getItem('lab.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('lab.' + k, JSON.stringify(v)); } catch { /* private mode */ } },
  del(k) { try { localStorage.removeItem('lab.' + k); } catch { /* ignore */ } },
};

const TEAM = location.pathname.startsWith('/admin');
const S = {
  token: LS.get('token', ''),
  user: LS.get('user', null), // {id, username, name, role}
  get isAdmin() { return this.user?.role === 'admin'; },
};

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- icons
const P = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ICON = {
  wrench: P('<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>'),
  home: P('<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
  inbox: P('<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>'),
  lab: P('<path d="M9 3h6M10 3v6L4.5 18.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7 15h10"/>'),
  menu: P('<path d="M4 7h16M4 12h16M4 17h16"/>'),
  alert: P('<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>'),
  search: P('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'),
  info: P('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'),
  check: P('<path d="M5 12l5 5 9-10"/>'),
  plus: P('<path d="M12 5v14M5 12h14"/>'),
  print: P('<path d="M7 9V4h10v5M7 17H4v-7h16v7h-3M7 14h10v6H7z"/>'),
  users: P('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/>'),
  key: P('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>'),
  out: P('<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>'),
  xls: P('<path d="M6 3h9l4 4v14H6z"/><path d="M9 11l5 6M14 11l-5 6"/>'),
  cam: P('<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'),
  eye: P('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
  edit: P('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13 7l4 4"/>'),
  note: P('<path d="M5 3h10l4 4v14H5z"/><path d="M9 12h6M9 16h4"/>'),
  sun: P('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  moon: P('<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>'),
  back: P('<path d="M9 6l6 6-6 6"/>'),
  qr: P('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/>'),
  // device types
  pc: P('<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/>'),
  laptop: P('<rect x="5" y="5" width="14" height="10" rx="1"/><path d="M2 19h20l-2-4H4z"/>'),
  projector: P('<rect x="2" y="8" width="20" height="9" rx="2"/><circle cx="16" cy="12.5" r="2.5"/><path d="M6 12h4M5 17v2M19 17v2"/>'),
  board: P('<rect x="3" y="4" width="18" height="12" rx="1"/><path d="M12 16v4M8 20h8M7 9l3 3 3-4 4 4"/>'),
  printer: P('<path d="M7 9V4h10v5M7 17H4v-7h16v7h-3M7 14h10v6H7z"/>'),
  microscope: P('<path d="M6 20h12M9 20a6 6 0 0 1 0-12M10 4l4 2-3 6-4-2zM12 11l2 4"/>'),
  screen: P('<rect x="2" y="4" width="20" height="13" rx="1.5"/><path d="M9 21h6M12 17v4"/>'),
  network: P('<rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 17h.01M11 17h.01M12 14V9M8 6a6 6 0 0 1 8 0M5.5 3.5a10 10 0 0 1 13 0"/>'),
  other: P('<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9 9h6v6H9z"/>'),
  // problems
  power: P('<path d="M12 3v8M6.3 7a8 8 0 1 0 11.4 0"/>'),
  input: P('<rect x="2" y="7" width="20" height="10" rx="2"/><path d="M6 11h.01M10 11h.01M14 11h.01M18 11h.01M7 14h10"/>'),
  software: P('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 13l-2 2 2 2M15 13l2 2-2 2"/>'),
  sound: P('<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 9a4 4 0 0 1 0 6M19.5 6.5a8 8 0 0 1 0 11"/>'),
  slow: P('<circle cx="12" cy="13" r="8"/><path d="M12 13l3-3M12 3v2"/>'),
  physical: P('<path d="M4 4h16v16H4z"/><path d="M10 4l2 6-4 3 5 7"/>'),
};

// ---------- reference lists (keys stored in the database, Arabic labels translated by t())
const STATUS = {
  ok: 'يعمل',
  needs_fix: 'يحتاج صيانة',
  in_repair: 'قيد الصيانة',
  out: 'خارج الخدمة',
};
const REQ_STATUS = { new: 'جديد', progress: 'قيد العمل', done: 'تم الإصلاح', closed: 'مغلق' };
const DAMAGE = {
  power: 'لا يشتغل / كهرباء',
  screen: 'الشاشة / العرض',
  input: 'لوحة المفاتيح أو الفأرة',
  software: 'البرامج أو النظام',
  network: 'الإنترنت أو الشبكة',
  sound: 'الصوت',
  slow: 'بطيء جداً',
  physical: 'كسر أو تلف',
  other: 'مشكلة أخرى',
};
const DAMAGE_IC = { power: 'power', screen: 'screen', input: 'input', software: 'software', network: 'network', sound: 'sound', slow: 'slow', physical: 'physical', other: 'other' };
const TYPES = {
  pc: 'حاسب مكتبي', laptop: 'حاسب محمول', projector: 'جهاز عرض', board: 'سبورة ذكية', printer: 'طابعة',
  microscope: 'مجهر', screen: 'شاشة', network: 'جهاز شبكة', other: 'جهاز آخر',
};
const LOG_KIND = {
  created: 'أُضيف الجهاز', edit: 'تعديل البيانات', report: 'بلاغ من طالب', status: 'تغيير الحالة', maint: 'صيانة',
  note: 'ملاحظة', req_start: 'بدء العمل على البلاغ', req_done: 'إغلاق البلاغ — تم الإصلاح', req_closed: 'إغلاق البلاغ — بدون إصلاح', req_reopen: 'إعادة فتح البلاغ',
};

const stBadge = (s) => `<span class="badge st-${esc(s)}">${t(STATUS[s] || s)}</span>`;
const rqBadge = (s) => `<span class="badge rq-${esc(s)}">${t(REQ_STATUS[s] || s)}</span>`;
const dmg = (k) => (k ? t(DAMAGE[k] || k) : '');
const typeName = (k) => t(TYPES[k] || TYPES.other);
const typeIc = (k) => ICON[k] || ICON.other;
const labName = (l) => (LANG === 'en' && (l.name_en || l.lab_name_en)) ? (l.name_en || l.lab_name_en) : (l.name || l.lab_name || '');

// ---------- dates: 12-hour, Latin digits, isolated so they read correctly inside Arabic sentences
function fmtTime(ts, withTime = true) {
  if (!ts) return '—';
  const o = withTime ? { dateStyle: 'medium', timeStyle: 'short', hour12: true } : { dateStyle: 'medium' };
  return '⁨' + new Intl.DateTimeFormat(LANG === 'en' ? 'en-GB' : 'ar-u-nu-latn', o).format(new Date(ts)) + '⁩';
}
function ago(ts) {
  if (!ts) return '—';
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return t('الآن');
  if (m < 60) return t('قبل {n} دقيقة', { n: m });
  const h = Math.round(m / 60);
  if (h < 24) return t('قبل {n} ساعة', { n: h });
  const d = Math.round(h / 24);
  if (d < 45) return t('قبل {n} يوم', { n: d });
  return fmtTime(ts, false);
}

// ---------- UI helpers
function toast(msg, bad) {
  const el = document.createElement('div');
  el.className = 'toast' + (bad ? ' bad' : '');
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), bad ? 4200 : 2400);
}

function sheet(html, onMount) {
  const bg = document.createElement('div');
  bg.className = 'sheet-bg';
  bg.innerHTML = `<div class="sheet">${html}</div>`;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(bg);
  $$('[data-close]', bg).forEach((b) => b.addEventListener('click', close));
  if (onMount) onMount(bg.firstElementChild, close);
  return close;
}

function confirmDlg(msg, okText, danger) {
  return new Promise((resolve) => {
    sheet(`<h2>${esc(msg)}</h2><div class="grid2"><button class="btn ${danger ? 'btn-red' : 'primary'}" data-ok>${esc(okText || t('تأكيد'))}</button><button class="btn" data-close>${t('إلغاء')}</button></div>`,
      (el, close) => {
        $('[data-ok]', el).onclick = () => { close(); resolve(true); };
        $$('[data-close]', el).forEach((b) => b.addEventListener('click', () => resolve(false)));
      });
  });
}

function viewImage(src) {
  const v = document.createElement('div');
  v.className = 'viewer';
  v.innerHTML = `<img src="${esc(src)}" alt=""><button class="iconbtn" aria-label="${t('إغلاق')}">✕</button>`;
  v.onclick = () => v.remove();
  document.body.appendChild(v);
}

// password field with a show/hide eye
const pwField = (id, ph = '', ac = 'current-password') =>
  `<div class="pw-wrap"><input class="in" id="${id}" type="password" autocomplete="${ac}" placeholder="${esc(ph)}"><button type="button" data-eye="${id}" aria-label="${t('إظهار')}">${ICON.eye}</button></div>`;
function bindEyes(root) {
  $$('[data-eye]', root).forEach((b) => (b.onclick = () => { const i = $('#' + b.dataset.eye, root); i.type = i.type === 'password' ? 'text' : 'password'; }));
}

// busy button: disables while the promise runs and shows errors as a toast
async function busy(btn, fn) {
  if (btn.disabled) return;
  btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { btn.disabled = false; }
}

// photo → JPEG ≤1280px, so phone photos upload quickly and fit the database row limit
function shrinkPhoto(file, max = 1280, q = 0.8) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => (b ? resolve(b) : reject(new Error(t('تعذّر قراءة الصورة')))), 'image/jpeg', q);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error(t('تعذّر قراءة الصورة'))); };
    img.src = url;
  });
}

// QR code as inline SVG (vendor/qrcode.js)
function qrSvg(text) {
  const q = qrcode(0, 'M');
  q.addData(text);
  q.make();
  const n = q.getModuleCount();
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + 2} ${r + 2}h1v1h-1z`;
  return `<svg viewBox="0 0 ${n + 4} ${n + 4}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}

// ---------- API
async function api(method, path, body) {
  const headers = { 'x-token': S.token };
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
  let res;
  try {
    res = await fetch('/api' + path, { method, headers, body: payload });
  } catch {
    setNet(false);
    throw new Error(t('لا يوجد اتصال بالإنترنت'));
  }
  setNet(true);
  const data = await res.json().catch(() => ({ ok: false, error: t('خطأ في الخادم') + ' (' + res.status + ')' }));
  if (res.status === 401 && TEAM && S.token && !/login|recover|me\/password/.test(path)) logout(true);
  if (!res.ok || data.ok === false) throw new Error(t(data.error || 'حدث خطأ'));
  return data;
}
function setNet(on) { const d = $('#netdot'); if (d) d.classList.toggle('off', !on); }

function logout(expired) {
  if (S.token && !expired) fetch('/api/logout', { method: 'POST', headers: { 'x-token': S.token } }).catch(() => {});
  S.token = ''; S.user = null; LS.del('token'); LS.del('user');
  if (expired) toast(t('انتهت الجلسة — سجّل الدخول'), true);
  location.hash = '#/';
  route(true);
}

// ---------- theme (light / dark) + language (ar / en)
function applyTheme() {
  const th = LS.get('theme', '');
  if (th) document.documentElement.dataset.theme = th; else delete document.documentElement.dataset.theme;
}
function currentTheme() {
  return document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
}
function prefsButtons() {
  return `<button class="iconbtn" data-pref="theme" title="${t('الوضع الداكن / الفاتح')}">${currentTheme() === 'dark' ? ICON.sun : ICON.moon}</button>
    <button class="iconbtn langbtn" data-pref="lang" title="${LANG === 'en' ? 'العربية' : 'English'}">${LANG === 'en' ? 'ع' : 'EN'}</button>`;
}
function bindPrefs(root) {
  $$('[data-pref="theme"]', root).forEach((b) => (b.onclick = () => { LS.set('theme', currentTheme() === 'dark' ? 'light' : 'dark'); applyTheme(); renderHeader(); }));
  $$('[data-pref="lang"]', root).forEach((b) => (b.onclick = () => { setLang(LANG === 'en' ? 'ar' : 'en'); route(true); }));
}

// ---------- CSV (opens in Excel with Arabic intact thanks to the BOM)
function downloadCsv(name, rows) {
  const cell = (v) => { const s = v == null ? '' : String(v); return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const blob = new Blob(['﻿' + rows.map((r) => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
const csvTime = (ts) => (ts ? new Date(ts).toLocaleString('en-GB', { hour12: true }) : '');

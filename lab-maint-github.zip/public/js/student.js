// Student pages: report a problem (lab → device → problem), get a report number, track it, about the project.
'use strict';

const PUB = { labs: [], devices: [], about: null, at: 0 };
async function loadPub(force) {
  if (!force && PUB.at && Date.now() - PUB.at < 30e3) return PUB;
  const d = await api('GET', '/pub/labs');
  Object.assign(PUB, { labs: d.labs, devices: d.devices, about: d.about, at: Date.now() });
  return PUB;
}

const app = () => $('#app');
const stepDots = (n) => `<div class="stepdots">${[1, 2, 3].map((i) => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div>`;
const backLink = (href, label) => `<div class="crumbs"><a href="${href}">${LANG === 'en' ? '←' : '→'} ${esc(label)}</a></div>`;

async function studentRoute(p) {
  const el = app();
  if (p[0] === 'report' && !p[1]) return sReportLabs(el);
  if (p[0] === 'report') return sReportDevices(el, p[1]);
  if (p[0] === 'dev') return sReportForm(el, p[1]);
  if (p[0] === 'code' || p[0] === 'lcode') {
    await loadPub(true);
    if (p[0] === 'code') {
      const d = PUB.devices.find((x) => x.code === decodeURIComponent(p[1] || '').toUpperCase());
      location.replace(d ? `#/dev/${d.id}` : '#/report');
    } else {
      const l = PUB.labs.find((x) => x.code === decodeURIComponent(p[1] || '').toUpperCase());
      location.replace(l ? `#/report/${l.id}` : '#/report');
    }
    return;
  }
  if (p[0] === 'done') return sDone(el, p[1]);
  if (p[0] === 'track') return sTrack(el, p[1]);
  if (p[0] === 'about') return sAbout(el);
  return sHome(el);
}

async function sHome(el) {
  let about = PUB.about;
  if (!about) { try { about = (await loadPub()).about; } catch { about = {}; } }
  const school = LANG === 'en' ? about?.school_en || about?.school : about?.school;
  el.innerHTML = `
    <div class="hero">
      <span class="logo-lg">${ICON.wrench}</span>
      <h1>${t('صيانة المعامل')}</h1>
      <div class="muted">${school ? esc(school) : t('نظام بلاغات أعطال أجهزة المعامل')}</div>
    </div>
    <a class="bigact primary" href="#/report"><span class="di">${ICON.alert}</span><span><b>${t('أبلغ عن مشكلة')}</b><small>${t('جهاز لا يعمل في المعمل؟ أخبرنا خلال دقيقة')}</small></span></a>
    <a class="bigact soft" href="#/track"><span class="di">${ICON.search}</span><span><b>${t('تابع بلاغك')}</b><small>${t('اكتب رقم البلاغ لتعرف حالته')}</small></span></a>
    <a class="bigact soft" href="#/about"><span class="di">${ICON.info}</span><span><b>${t('عن المشروع')}</b><small>${t('الطلاب الذين صمّموا هذا النظام')}</small></span></a>
    <div class="footer-link"><a href="/admin">${ICON.key.replace('<svg', '<svg style="width:15px;height:15px;vertical-align:-3px"')} ${t('دخول فريق الصيانة')}</a></div>`;
}

async function sReportLabs(el) {
  el.innerHTML = `<div class="loading">${t('جارٍ التحميل…')}</div>`;
  await loadPub(true);
  el.innerHTML = `${backLink('#/', t('الرئيسية'))}${stepDots(1)}
    <h1>${t('في أي معمل الجهاز؟')}</h1>
    ${PUB.labs.length ? `<div class="list">${PUB.labs.map((l) => {
      const n = PUB.devices.filter((d) => d.lab_id === l.id).length;
      return `<a class="card labcard" style="margin:0" href="#/report/${l.id}"><div class="hd"><span class="li-ic">${ICON.lab}</span>
        <div class="grow" style="flex:1;min-width:0"><b style="font-size:17px">${esc(labName(l))}</b>
        <div class="muted small">${l.location ? esc(l.location) + ' · ' : ''}${t('{n} جهاز', { n })}</div></div>
        <span class="muted" style="transform:scaleX(${LANG === 'en' ? 1 : -1})">${ICON.back.replace('<svg', '<svg style="width:20px;height:20px"')}</span></div></a>`;
    }).join('')}</div>` : `<div class="empty">${t('لم تُضف أي معامل بعد')}</div>`}`;
}

async function sReportDevices(el, labId) {
  await loadPub();
  const lab = PUB.labs.find((l) => l.id === labId);
  if (!lab) { location.replace('#/report'); return; }
  const devs = PUB.devices.filter((d) => d.lab_id === labId);
  el.innerHTML = `${backLink('#/report', t('المعامل'))}${stepDots(2)}
    <h1>${t('اختر الجهاز')}</h1>
    <div class="muted" style="margin:-6px 0 12px">${esc(labName(lab))} · ${t('رقم الجهاز مكتوب على الملصق')}</div>
    ${devs.length ? `<div class="dgrid">${devs.map((d) => `
      <a class="dtile st-${esc(d.status)}" href="#/dev/${d.id}">
        ${d.open_reqs ? `<span class="flag" title="${t('عليه بلاغ مفتوح')}">!</span>` : ''}
        <span class="ic">${typeIc(d.type)}</span><b>${esc(d.name)}</b><span class="mono">${esc(d.code)}</span>
        ${d.status !== 'ok' ? stBadge(d.status) : ''}
      </a>`).join('')}</div>` : `<div class="empty">${t('لا توجد أجهزة في هذا المعمل')}</div>`}`;
}

async function sReportForm(el, devId) {
  await loadPub();
  let dev = PUB.devices.find((d) => d.id === devId);
  if (!dev) { await loadPub(true); dev = PUB.devices.find((d) => d.id === devId); }
  if (!dev) { location.replace('#/report'); return; }
  const lab = PUB.labs.find((l) => l.id === dev.lab_id) || {};
  const me = LS.get('reporter', { name: '', grade: '' });
  let problem = '', photo = null;
  el.innerHTML = `${backLink('#/report/' + dev.lab_id, labName(lab))}${stepDots(3)}
    <div class="card"><div class="row"><span class="li-ic" style="width:48px;height:48px;border-radius:14px;background:var(--primary-soft);color:var(--primary);display:grid;place-items:center">${typeIc(dev.type)}</span>
      <div class="grow"><b style="font-size:17px">${esc(dev.name)}</b><div class="muted small"><span class="mono">${esc(dev.code)}</span> · ${esc(labName(lab))}</div></div>${stBadge(dev.status)}</div>
      ${dev.open_reqs ? `<div class="alert info" style="margin-top:10px">${ICON.info.replace('<svg', '<svg style="width:20px;height:20px;flex:none"')}<span>${t('فريق الصيانة يعلم بمشكلة في هذا الجهاز. أرسل بلاغاً فقط إذا كانت مشكلة مختلفة.')}</span></div>` : ''}
    </div>
    <h2>${t('ما المشكلة؟')}</h2>
    <div class="pgrid" id="pg">${Object.keys(DAMAGE).map((k) => `<button class="pbtn" data-k="${k}">${ICON[DAMAGE_IC[k]]}${dmg(k)}</button>`).join('')}</div>
    <div class="field" style="margin-top:14px"><label class="f" id="dl">${t('اشرح المشكلة باختصار')}</label>
      <textarea class="in" id="desc" maxlength="1000" placeholder="${t('مثال: الشاشة تطفي بعد دقيقة')}"></textarea></div>
    <div class="field"><label class="f">${t('صورة (اختياري)')}</label>
      <div class="photo-pick"><label class="btn">${ICON.cam}<span id="phl">${t('أضف صورة')}</span><input type="file" id="ph" accept="image/*" hidden></label><span id="phv"></span></div></div>
    <div class="grid2">
      <div class="field"><label class="f">${t('اسمك (اختياري)')}</label><input class="in" id="nm" maxlength="60" value="${esc(me.name)}"></div>
      <div class="field"><label class="f">${t('الصف / الفصل (اختياري)')}</label><input class="in" id="gr" maxlength="30" value="${esc(me.grade)}"></div>
    </div>
    <button class="btn primary big" id="send">${t('إرسال البلاغ')}</button>`;
  $$('#pg .pbtn', el).forEach((b) => (b.onclick = () => {
    problem = b.dataset.k;
    $$('#pg .pbtn', el).forEach((x) => x.classList.toggle('on', x === b));
    $('#dl', el).classList.toggle('req', problem === 'other');
  }));
  $('#ph', el).onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    try {
      photo = await shrinkPhoto(f);
      $('#phv', el).innerHTML = `<img src="${URL.createObjectURL(photo)}" alt=""> <button class="btn sm danger" id="phx">${t('حذف')}</button>`;
      $('#phl', el).textContent = t('تغيير الصورة');
      $('#phx', el).onclick = () => { photo = null; $('#phv', el).innerHTML = ''; $('#phl', el).textContent = t('أضف صورة'); $('#ph', el).value = ''; };
    } catch (er) { toast(er.message, true); }
  };
  $('#send', el).onclick = (e) => busy(e.currentTarget, async () => {
    if (!problem) { toast(t('اختر نوع المشكلة'), true); $('#pg', el).scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
    const desc = $('#desc', el).value.trim();
    if (problem === 'other' && !desc) { toast(t('اكتب وصف المشكلة'), true); $('#desc', el).focus(); return; }
    const fd = new FormData();
    fd.append('device_id', dev.id); fd.append('problem', problem); fd.append('description', desc);
    fd.append('reporter', $('#nm', el).value.trim()); fd.append('grade', $('#gr', el).value.trim());
    if (photo) fd.append('photo', photo, 'photo.jpg');
    const r = await api('POST', '/pub/report', fd);
    LS.set('reporter', { name: $('#nm', el).value.trim(), grade: $('#gr', el).value.trim() });
    const mine = LS.get('mine', []); mine.unshift(r.no); LS.set('mine', mine.slice(0, 10));
    PUB.at = 0;
    location.hash = '#/done/' + r.no;
  });
}

function sDone(el, no) {
  el.innerHTML = `<div class="card ticket">
      <div class="okcircle">${ICON.check}</div>
      <h1 style="margin:0">${t('تم إرسال البلاغ، شكراً لك!')}</h1>
      <div class="muted" style="margin-top:12px">${t('رقم البلاغ')}</div>
      <div class="no">${esc(no)}</div>
      <div class="muted small">${t('احتفظ بهذا الرقم لمتابعة حالة البلاغ')}</div>
    </div>
    <div class="grid2"><a class="btn primary" href="#/track/${esc(no)}">${t('تابع البلاغ')}</a><a class="btn" href="#/report">${t('بلاغ آخر')}</a></div>
    <div class="footer-link"><a href="#/">${t('الرئيسية')}</a></div>`;
}

async function sTrack(el, no) {
  const mine = LS.get('mine', []);
  el.innerHTML = `${backLink('#/', t('الرئيسية'))}<h1>${t('تابع بلاغك')}</h1>
    <div class="card"><label class="f">${t('رقم البلاغ')}</label>
      <div class="row"><input class="in grow" id="no" inputmode="numeric" maxlength="7" value="${esc(no || '')}" style="font-size:20px;font-weight:700" placeholder="1001">
      <button class="btn primary" id="go">${t('بحث')}</button></div>
      ${mine.length ? `<div class="chips" style="margin-top:10px"><span class="muted small" style="align-self:center">${t('بلاغاتك:')}</span>${mine.map((n) => `<a class="chip sm" href="#/track/${n}">${n}</a>`).join('')}</div>` : ''}
    </div><div id="res"></div>`;
  const go = () => { const v = $('#no', el).value.replace(/\D/g, ''); if (v) location.hash = '#/track/' + v; };
  $('#go', el).onclick = go;
  $('#no', el).onkeydown = (e) => { if (e.key === 'Enter') go(); };
  if (!no) return;
  const res = $('#res', el);
  res.innerHTML = `<div class="loading">${t('جارٍ التحميل…')}</div>`;
  try {
    const { request: r } = await api('GET', '/pub/track/' + encodeURIComponent(no));
    const steps = ['new', 'progress', 'done'];
    const cur = r.status === 'closed' ? 2 : steps.indexOf(r.status);
    res.innerHTML = `<div class="card">
      <div class="row"><b class="grow" style="font-size:18px">${t('بلاغ رقم')} ${esc(r.no)}</b>${rqBadge(r.status)}</div>
      <div class="steps">${steps.map((s, i) => `<div class="${i < cur ? 'done' : i === cur ? 'cur' : ''}">${t(i === 2 && r.status === 'closed' ? REQ_STATUS.closed : REQ_STATUS[s])}</div>`).join('')}</div>
      <dl class="kv" style="margin-top:12px">
        <dt>${t('الجهاز')}</dt><dd>${esc(r.device_name || '—')} <span class="mono muted">${esc(r.device_code || '')}</span></dd>
        <dt>${t('المعمل')}</dt><dd>${esc(labName(r))}</dd>
        <dt>${t('المشكلة')}</dt><dd>${dmg(r.problem)}</dd>
        <dt>${t('تاريخ البلاغ')}</dt><dd>${fmtTime(r.created_at)}</dd>
        ${r.closed_at ? `<dt>${t('تاريخ الإغلاق')}</dt><dd>${fmtTime(r.closed_at)}</dd>` : ''}
        ${r.resolution ? `<dt>${t('ملاحظة الفريق')}</dt><dd>${esc(r.resolution)}</dd>` : ''}
      </dl></div>`;
  } catch (e) { res.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
}

function aboutHtml(a) {
  a = a || {};
  const en = LANG === 'en';
  const title = (en ? a.title_en || a.title : a.title) || t('نظام صيانة أجهزة المعامل');
  const school = en ? a.school_en || a.school : a.school;
  const desc = (en ? a.description_en || a.description : a.description) || t('نظام يساعد المدرسة على متابعة أجهزة المعامل: يبلّغ الطالب عن العطل، ويستلمه فريق الصيانة، ويُحفظ سجل كامل لكل جهاز.');
  const students = a.students || [];
  return `<div class="card" style="text-align:center">
      <span class="logo-lg">${ICON.wrench}</span>
      <h1 style="margin:4px 0">${esc(title)}</h1>
      ${school ? `<div class="muted">${esc(school)}${a.year ? ' · ' + esc(a.year) : ''}</div>` : a.year ? `<div class="muted">${esc(a.year)}</div>` : ''}
      <p style="margin:12px 0 0;white-space:pre-wrap">${esc(desc)}</p>
    </div>
    <div class="card"><h2 style="margin-top:0">${t('فريق العمل من الطلاب')}</h2>
      ${students.length ? `<div class="about-names">${students.map((s) => `<div><b>${esc(s.name)}</b>${s.role ? `<span>${esc(s.role)}</span>` : ''}</div>`).join('')}</div>`
        : `<div class="muted">${t('لم تُضف أسماء الطلاب بعد')}</div>`}
      ${a.supervisor ? `<div class="byline" style="margin-top:14px">${ICON.users.replace('<svg', '<svg style="width:18px;height:18px"')} ${t('إشراف:')} <b>${esc(a.supervisor)}</b></div>` : ''}
    </div>`;
}

async function sAbout(el) {
  el.innerHTML = `<div class="loading">${t('جارٍ التحميل…')}</div>`;
  const { about } = await api('GET', '/pub/about');
  el.innerHTML = backLink('#/', t('الرئيسية')) + aboutHtml(about);
}

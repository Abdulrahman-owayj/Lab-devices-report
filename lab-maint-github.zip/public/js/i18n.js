// Arabic is the source language: every UI string is written in Arabic and t() looks up its English twin.
// Server error messages are Arabic too, so they translate through the same dictionary.
// Placeholders: {n}; English plurals: {n|device|devices}.
'use strict';

let LANG = (() => { try { return JSON.parse(localStorage.getItem('lab.lang')) || 'ar'; } catch { return 'ar'; } })();

function setLang(l) {
  LANG = l === 'en' ? 'en' : 'ar';
  try { localStorage.setItem('lab.lang', JSON.stringify(LANG)); } catch { /* private mode */ }
  document.documentElement.lang = LANG;
  document.documentElement.dir = LANG === 'en' ? 'ltr' : 'rtl';
}
setLang(LANG);

function t(s, vars) {
  let out = LANG === 'en' && EN[s] != null ? EN[s] : s;
  if (vars) {
    out = out.replace(/\{(\w+)\|([^|}]*)\|([^}]*)\}/g, (_, k, one, many) => (Number(vars[k]) === 1 ? one : many));
    out = out.replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null ? vars[k] : m));
  }
  return out;
}

const EN = {
  // statuses + lists
  'يعمل': 'Working', 'يحتاج صيانة': 'Needs repair', 'قيد الصيانة': 'Being repaired', 'خارج الخدمة': 'Out of service',
  'جديد': 'New', 'قيد العمل': 'In progress', 'تم الإصلاح': 'Fixed', 'مغلق': 'Closed',
  'لا يشتغل / كهرباء': "Won't turn on / power", 'الشاشة / العرض': 'Screen / display', 'لوحة المفاتيح أو الفأرة': 'Keyboard or mouse',
  'البرامج أو النظام': 'Software or system', 'الإنترنت أو الشبكة': 'Internet or network', 'الصوت': 'Sound', 'بطيء جداً': 'Very slow',
  'كسر أو تلف': 'Broken or damaged', 'مشكلة أخرى': 'Other problem',
  'حاسب مكتبي': 'Desktop PC', 'حاسب محمول': 'Laptop', 'جهاز عرض': 'Projector', 'سبورة ذكية': 'Smart board', 'طابعة': 'Printer',
  'مجهر': 'Microscope', 'شاشة': 'Monitor / TV', 'جهاز شبكة': 'Network device', 'جهاز آخر': 'Other device',
  'أُضيف الجهاز': 'Device added', 'تعديل البيانات': 'Edit details', 'بلاغ من طالب': 'Student report', 'تغيير الحالة': 'Change status',
  'صيانة': 'Maintenance', 'ملاحظة': 'Note', 'بدء العمل على البلاغ': 'Started work on report', 'إغلاق البلاغ — تم الإصلاح': 'Report closed — fixed',
  'إغلاق البلاغ — بدون إصلاح': 'Report closed — no repair', 'إعادة فتح البلاغ': 'Reopen report',
  // general
  'الآن': 'just now', 'قبل {n} دقيقة': '{n} min ago', 'قبل {n} ساعة': '{n} {n|hour|hours} ago', 'قبل {n} يوم': '{n} {n|day|days} ago',
  'تأكيد': 'Confirm', 'إلغاء': 'Cancel', 'إغلاق': 'Close', 'إظهار': 'Show', 'حذف': 'Delete', 'حفظ': 'Save', 'بحث': 'Search', 'إضافة': 'Add',
  'تعذّر قراءة الصورة': "Couldn't read the photo", 'لا يوجد اتصال بالإنترنت': 'No internet connection', 'خطأ في الخادم': 'Server error',
  'حدث خطأ': 'Something went wrong', 'انتهت الجلسة — سجّل الدخول': 'Session ended — please log in', 'الوضع الداكن / الفاتح': 'Dark / light mode',
  'صيانة المعامل': 'Lab Care', 'بلاغات الأعطال': 'Fault reports', 'جارٍ التحميل…': 'Loading…', 'الرئيسية': 'Home',
  'تم الحفظ': 'Saved', 'تم الحذف': 'Deleted', 'ملاحظات': 'Notes', 'الحالة': 'Status', 'التاريخ': 'Date', 'الوصف': 'Description', 'بواسطة': 'By',
  // student
  'نظام بلاغات أعطال أجهزة المعامل': 'Report broken lab devices', 'أبلغ عن مشكلة': 'Report a problem',
  'جهاز لا يعمل في المعمل؟ أخبرنا خلال دقيقة': 'A lab device not working? Tell us in a minute', 'تابع بلاغك': 'Track your report',
  'اكتب رقم البلاغ لتعرف حالته': 'Enter your report number to see its status', 'عن المشروع': 'About the project',
  'الطلاب الذين صمّموا هذا النظام': 'The students who built this system', 'دخول فريق الصيانة': 'Maintenance team login',
  'في أي معمل الجهاز؟': 'Which lab is the device in?', 'لم تُضف أي معامل بعد': 'No labs added yet', 'المعامل': 'Labs',
  '{n} جهاز': '{n} {n|device|devices}', 'اختر الجهاز': 'Choose the device', 'رقم الجهاز مكتوب على الملصق': 'The device number is on its sticker',
  'عليه بلاغ مفتوح': 'Already reported', 'لا توجد أجهزة في هذا المعمل': 'No devices in this lab',
  'فريق الصيانة يعلم بمشكلة في هذا الجهاز. أرسل بلاغاً فقط إذا كانت مشكلة مختلفة.': 'The maintenance team already knows about a problem with this device. Only report if it is a different problem.',
  'ما المشكلة؟': "What's the problem?", 'اشرح المشكلة باختصار': 'Describe the problem briefly', 'مثال: الشاشة تطفي بعد دقيقة': 'e.g. the screen turns off after a minute',
  'صورة (اختياري)': 'Photo (optional)', 'أضف صورة': 'Add a photo', 'تغيير الصورة': 'Change photo', 'اسمك (اختياري)': 'Your name (optional)',
  'الصف / الفصل (اختياري)': 'Grade / class (optional)', 'إرسال البلاغ': 'Send report', 'اختر نوع المشكلة': 'Choose the problem type',
  'اكتب وصف المشكلة': 'Describe the problem', 'تم إرسال البلاغ، شكراً لك!': 'Report sent — thank you!', 'رقم البلاغ': 'Report number',
  'احتفظ بهذا الرقم لمتابعة حالة البلاغ': 'Keep this number to track your report', 'تابع البلاغ': 'Track report', 'بلاغ آخر': 'Another report',
  'بلاغاتك:': 'Your reports:', 'بلاغ رقم': 'Report', 'الجهاز': 'Device', 'المعمل': 'Lab', 'المشكلة': 'Problem', 'تاريخ البلاغ': 'Reported',
  'تاريخ الإغلاق': 'Closed', 'ملاحظة الفريق': 'Team note', 'نظام صيانة أجهزة المعامل': 'Lab Device Maintenance System',
  'نظام يساعد المدرسة على متابعة أجهزة المعامل: يبلّغ الطالب عن العطل، ويستلمه فريق الصيانة، ويُحفظ سجل كامل لكل جهاز.': 'A system that helps the school look after its lab devices: students report faults, the maintenance team receives them, and every device keeps a full history.',
  'فريق العمل من الطلاب': 'Student project team', 'لم تُضف أسماء الطلاب بعد': 'Student names not added yet', 'إشراف:': 'Supervised by:', 'طالب': 'Student',
  // team
  'البلاغات': 'Reports', 'القائمة': 'Menu', 'وصل بلاغ جديد': 'New report received', 'اسم المستخدم': 'Username', 'كلمة المرور': 'Password', 'دخول': 'Log in',
  'نسيت كلمة المرور؟': 'Forgot password?', 'صفحة بلاغات الطلاب': 'Student report page',
  'اطلب من مدير النظام إعادة تعيين كلمة مرورك من صفحة «المستخدمون». وإذا نسي المدير كلمة مروره يستخدم رمز الاستعادة:': 'Ask the system admin to reset your password from the “Users” page. If the admin forgot their own password, use the recovery code:',
  'رمز الاستعادة': 'Recovery code', 'كلمة المرور الجديدة': 'New password', 'تعيين كلمة المرور': 'Set password', 'تم تعيين كلمة المرور — سجّل الدخول': 'Password set — log in now',
  'أهلاً {name}': 'Hello {name}', 'بلاغات جديدة': 'New reports', 'أجهزة معطّلة': 'Broken devices', 'أجهزة تعمل': 'Working devices',
  'أُصلحت هذا الأسبوع': 'Fixed this week', 'البلاغات المفتوحة': 'Open reports', 'عرض الكل': 'View all', 'لا توجد بلاغات مفتوحة': 'No open reports',
  'حالة المعامل': 'Lab status', 'إضافة معمل': 'Add lab', '{n} معطّل': '{n} broken', 'المفتوحة': 'Open', 'جديدة': 'New', 'المنتهية': 'Finished', 'الكل': 'All',
  'كل المعامل': 'All labs', 'لا توجد بلاغات هنا': 'No reports here', 'المُبلّغ': 'Reported by', 'بدون اسم': 'No name', 'المسؤول': 'Assigned to', 'أُغلق': 'Closed',
  'ما تم إصلاحه': 'What was fixed', 'سبب الإغلاق': 'Reason for closing', 'ابدأ العمل': 'Start work', 'إغلاق بدون إصلاح': 'Close without repair',
  'إضافة ملاحظة': 'Add note', 'سجل البلاغ': 'Report history', 'بلاغات أخرى لنفس الجهاز': 'Other reports for this device',
  'ما الذي تم إصلاحه؟': 'What was fixed?', 'مثال: تم تغيير كابل الشاشة': 'e.g. replaced the screen cable', 'حالة الجهاز بعد الإصلاح': 'Device status after the repair',
  'أغلق أيضاً {n} بلاغ آخر مفتوح على هذا الجهاز': 'Also close {n} other open {n|report|reports} on this device',
  'لا يوجد عطل': 'No fault found', 'بلاغ مكرر': 'Duplicate report', 'مشكلة في طريقة الاستخدام': 'Usage problem', 'يحتاج قطعة غير متوفرة': 'Needs a part not in stock',
  'إغلاق البلاغ': 'Close report', 'ملاحظة للمهندس القادم…': 'A note for the next engineer…', 'لا يوجد سجل بعد': 'No history yet', 'كلها تعمل': 'All working',
  'مدير النظام يضيف المعامل والأجهزة': 'The system admin adds labs and devices', 'تعديل المعمل': 'Edit lab', 'اسم المعمل': 'Lab name',
  'مثال: معمل الحاسب 1': 'e.g. Computer Lab 1', 'الاسم بالإنجليزية (اختياري)': 'English name (optional)', 'رمز المعمل': 'Lab code', 'المكان': 'Location',
  'مثال: الدور الأول': 'e.g. First floor', 'الرمز يظهر في أرقام الأجهزة، مثل LAB1-01': 'The code starts every device number, e.g. LAB1-01',
  'معطّل': 'Broken', 'إضافة أجهزة': 'Add devices', 'ملصقات QR': 'QR stickers', 'بلاغات مفتوحة': 'Open reports', 'لا توجد أجهزة بهذه الحالة': 'No devices with this status',
  'حذف المعمل': 'Delete lab', 'سيُحذف المعمل و{n} جهاز مع كل البلاغات والسجلات. لا يمكن التراجع.': 'The lab and its {n} {n|device|devices} will be deleted with all reports and history. This cannot be undone.',
  'اكتب رمز المعمل للتأكيد:': 'Type the lab code to confirm:', 'حذف نهائي': 'Delete permanently', 'إضافة أجهزة إلى': 'Add devices to', 'نوع الجهاز': 'Device type',
  'العدد': 'How many', 'اسم الجهاز': 'Device name', 'مثال: جهاز الطالب': 'e.g. Student PC', 'ستُسمّى: {a} 1، {a} 2 … {a} {n}': 'They will be named: {a} 1, {a} 2 … {a} {n}',
  'الشركة المصنّعة': 'Brand', 'الموديل': 'Model', 'الرقم التسلسلي': 'Serial number', 'أُضيف {n} جهاز': '{n} {n|device|devices} added',
  'السجل الكامل': 'Full history', 'المشاكل السابقة': 'Previous problems', 'ملاحظات المهندسين': "Engineers' notes", 'وصف العطل': 'Fault description',
  'آخر صيانة': 'Last maintenance', 'لم تُسجّل صيانة بعد': 'No maintenance recorded yet', 'تسجيل صيانة': 'Record maintenance', 'بيانات الجهاز': 'Device details',
  'أُضيف': 'Added', 'حذف الجهاز': 'Delete device', 'لا توجد مشاكل سابقة لهذا الجهاز': 'No previous problems for this device',
  'تغيير حالة الجهاز': 'Change device status', 'نوع العطل': 'Fault type', 'اختر نوع العطل': 'Choose the fault type', 'ما الذي تم عمله؟': 'What was done?',
  'مثال: تنظيف الجهاز وتحديث النظام': 'e.g. cleaned the device and updated the system', 'حالة الجهاز بعد الصيانة': 'Device status after maintenance',
  'أغلق {n} بلاغ مفتوح على هذا الجهاز (تم الإصلاح)': 'Close {n} open {n|report|reports} on this device (fixed)', 'رقم الجهاز': 'Device number',
  'حذف الجهاز {c} مع سجله وبلاغاته؟': 'Delete device {c} with its history and reports?', 'طباعة': 'Print',
  'ألصق ملصق كل جهاز عليه، وضع ملصق المعمل على الباب. الطالب يمسح الرمز بجواله ليبلّغ مباشرة.': 'Stick each label on its device and the lab poster on the door. Students scan the code with their phone to report straight away.',
  'عطل في جهاز؟ امسح الرمز': 'Device not working? Scan the code', 'امسح للإبلاغ عن مشكلة': 'Scan to report a problem',
  'مدير النظام': 'System admin', 'فريق الصيانة': 'Maintenance team', 'المستخدمون وكلمات المرور': 'Users & passwords', 'تغيير كلمة المرور': 'Change password',
  'تصدير إلى Excel': 'Export to Excel', 'تسجيل الخروج': 'Log out', 'الصف / الفصل': 'Grade / class', 'الحدث': 'Event', 'تم تنزيل 3 ملفات': '3 files downloaded',
  'المستخدمون': 'Users', 'مستخدم جديد': 'New user', 'أنت': 'you', 'آخر دخول': 'Last login', 'مدير': 'Admin', 'فني صيانة': 'Technician', 'موقوف': 'Disabled',
  'المدير يضيف المعامل والأجهزة والمستخدمين. فني الصيانة يستلم البلاغات ويحدّث حالة الأجهزة.': 'Admins add labs, devices and users. Technicians receive reports and update device status.',
  'الاسم': 'Name', 'الصلاحية': 'Role', 'إعادة تعيين كلمة المرور': 'Reset password', 'اتركها فارغة لعدم التغيير': 'Leave empty to keep it',
  'الحساب مفعّل': 'Account active', 'حذف المستخدم': 'Delete user', 'حذف المستخدم {n}؟': 'Delete user {n}?', 'تم تعيين كلمة المرور الجديدة': 'New password set',
  'كلمة المرور الحالية': 'Current password', 'أعد كتابة كلمة المرور الجديدة': 'Repeat the new password', 'كلمتا المرور غير متطابقتين': "The passwords don't match",
  'تم تغيير كلمة المرور': 'Password changed', 'تعديل صفحة «عن المشروع»': 'Edit “About the project”', 'اسم الطالب': 'Student name', 'الدور (اختياري)': 'Role (optional)',
  'إضافة طالب': 'Add student', 'اسم المشروع': 'Project name', 'اسم المشروع بالإنجليزية': 'Project name (English)', 'اسم المدرسة': 'School name',
  'اسم المدرسة بالإنجليزية': 'School name (English)', 'المعلم المشرف': 'Supervising teacher', 'العام الدراسي': 'School year', 'نبذة عن المشروع': 'About the project (Arabic)',
  'النبذة بالإنجليزية': 'About the project (English)',
  // server messages
  'بيانات غير صالحة': 'Invalid data', 'الصورة كبيرة جداً': 'The photo is too large', 'بلاغات كثيرة — حاول بعد قليل': 'Too many reports — try again shortly',
  'الجهاز غير موجود': 'Device not found', 'سجّل الدخول': 'Please log in', 'للمدير فقط': 'Admins only', 'لا يوجد بلاغ بهذا الرقم': 'No report with this number',
  'محاولات كثيرة — انتظر 5 دقائق': 'Too many attempts — wait 5 minutes', 'اسم المستخدم أو كلمة المرور غير صحيحة': 'Wrong username or password',
  'استعادة كلمة المرور غير مفعّلة — اطلب من المدير إعادة تعيينها': 'Password recovery is not enabled — ask the admin to reset it',
  'رمز الاستعادة غير صحيح': 'Wrong recovery code', 'اسم المستخدم غير موجود': 'Username not found', 'كلمة المرور الحالية غير صحيحة': 'Current password is wrong',
  'المعمل غير موجود': 'Lab not found', 'رمز الجهاز غير صالح': 'Invalid device number', 'الرمز مستخدم لجهاز آخر': 'That number belongs to another device',
  'نقل إلى معمل آخر': 'Moved to another lab', 'اختر الحالة': 'Choose a status', 'اكتب ما تم عمله': 'Write what was done', 'اكتب الملاحظة': 'Write the note',
  'اسم المستخدم: 3 أحرف إنجليزية أو أرقام على الأقل': 'Username: at least 3 English letters or digits', 'اسم المستخدم موجود': 'Username already exists',
  'المستخدم غير موجود': 'User not found', 'يجب أن يبقى مدير واحد على الأقل': 'At least one admin must remain', 'لا يمكنك إيقاف حسابك': "You can't disable your own account",
  'لا يمكنك حذف حسابك': "You can't delete your own account", 'غير موجود': 'Not found', 'كلمة المرور 4 أحرف على الأقل': 'Password must be at least 4 characters',
  'رمز المعمل: حروف إنجليزية أو أرقام (حتى 8)': 'Lab code: English letters or digits (up to 8)', 'رمز المعمل مستخدم': 'Lab code already used',
  'اكتب اسم المعمل': 'Enter the lab name', 'البلاغ مغلق': 'The report is closed', 'اكتب ما تم إصلاحه': 'Write what was fixed', 'اكتب سبب الإغلاق': 'Write the reason for closing',
  'البلاغ مفتوح': 'The report is open', 'إجراء غير معروف': 'Unknown action',
};

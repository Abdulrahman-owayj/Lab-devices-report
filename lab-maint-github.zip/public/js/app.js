// Router + header. "/" = students, "/admin" = maintenance team.
'use strict';

function renderHeader() {
  $('#brandIc').innerHTML = ICON.wrench;
  $('#brandLink').href = '#/';
  $('#projName').textContent = t('صيانة المعامل');
  $('#userName').textContent = TEAM ? (S.user ? S.user.name + ' · ' + (S.isAdmin ? t('مدير') : t('فني صيانة')) : t('فريق الصيانة')) : t('بلاغات الأعطال');
  $('#netdot').classList.toggle('hidden', !TEAM || !S.token);
  $('#prefs').innerHTML = prefsButtons();
  bindPrefs($('#prefs'));
}

let lastHash = null;
async function route(force) {
  const h = location.hash.replace(/^#\/?/, '');
  if (!force && h === lastHash) return;
  lastHash = h;
  const parts = h.split(/[/?]/).filter(Boolean);
  renderHeader();
  window.scrollTo(0, 0);
  try {
    if (TEAM) await teamRoute(parts);
    else await studentRoute(parts);
  } catch (e) {
    $('#app').innerHTML = `<div class="alert bad">${esc(e.message)}</div><div class="footer-link"><a href="#/">${t('الرئيسية')}</a></div>`;
  }
}

window.addEventListener('hashchange', () => route());
applyTheme();
// QR entry points: /d/<device code> and /l/<lab code> → the student report flow
{
  const m = location.pathname.match(/^\/([dl])\/([A-Za-z0-9-]{1,30})$/);
  if (m && !TEAM) {
    history.replaceState(null, '', `/#/${m[1] === 'd' ? 'code' : 'lcode'}/${m[2]}`);
  }
}
route(true);

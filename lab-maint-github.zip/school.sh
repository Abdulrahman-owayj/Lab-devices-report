#!/usr/bin/env bash
# Runs wrangler against the SCHOOL Cloudflare account without switching the default login
# that other projects deploy with.   Usage:  bash school.sh deploy      bash school.sh secret put RECOVERY_KEY
# The school login lives in ~/.wrangler/config/default.toml.school; the account ID in .school-account (both untracked).
set -e
cd "$(dirname "$0")"
C=~/.wrangler/config
W="node node_modules/wrangler/bin/wrangler.js"
ACCOUNT=$(tr -d "[:space:]" < .school-account)

exp=$(grep '^expiration_time' $C/default.toml.school | sed 's/.*"\(.*\)"/\1/')
if [ "$(node -e "console.log(Date.parse('$exp') - Date.now() < 120000 ? 1 : 0)")" = 1 ]; then
  # access token expired: let wrangler refresh it with the school login in place for a few seconds, then swap back
  cp $C/default.toml $C/default.toml.swap
  trap 'cp $C/default.toml.swap $C/default.toml; rm -f $C/default.toml.swap' EXIT
  cp $C/default.toml.school $C/default.toml
  $W whoami >/dev/null 2>&1 || true
  cp $C/default.toml $C/default.toml.school
  cp $C/default.toml.swap $C/default.toml && rm -f $C/default.toml.swap
  trap - EXIT
fi
TOK=$(grep '^oauth_token' $C/default.toml.school | sed 's/.*"\(.*\)"/\1/')
CLOUDFLARE_API_TOKEN="$TOK" CLOUDFLARE_ACCOUNT_ID=$ACCOUNT $W "$@"

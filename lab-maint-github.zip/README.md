# Lab Care — school lab device maintenance (صيانة المعامل)

A school student project: students report broken lab devices from their phones, and the maintenance team receives the
reports, updates each device's status and keeps a full history for every device. Arabic / English, light / dark.

نظام لصيانة أجهزة معامل المدرسة: يبلّغ الطالب عن العطل من جواله، ويستلمه فريق الصيانة، ويُحفظ سجل كامل لكل جهاز.

**Live:** https://lab-maint.lab-maint.workers.dev

| Page | Who | What |
|---|---|---|
| `/` | Students | Report a problem (lab → device → problem type, short description, optional photo, name, class) → gets a report number. Track a report by number. About the project. |
| `/d/<CODE>` | Students | QR sticker on a device → opens the report form for that device |
| `/l/<CODE>` | Students | QR poster on the lab door → that lab's device list |
| `/admin` | Maintenance team | Username + password. Dashboard, report inbox (start / fixed / close / reopen / note), labs → devices, device page with status, last maintenance, previous problems, engineers' notes and full log. Change status (needs repair + fault type), record maintenance, add note. QR stickers to print. Export to Excel (3 CSV files). |

**Roles:** `admin` adds labs, devices (bulk: "25 × Desktop PC"), users, edits the About page and resets passwords. `tech` (technician) handles reports and device status.

**Accounts:** a brand-new deployment creates `admin` / `2020`. **Change it right after the first login** (Menu → Change password).
Admins reset anyone's password from Menu → Users. If the admin forgets their own password: login page → "Forgot password?" →
the recovery code you set as the Cloudflare secret `RECOVERY_KEY` (keep it somewhere safe; it is not in this repo).

**How a report flows:** student reports → device turns *needs repair* → technician presses *Start work* (device *being repaired*) → *Fixed* with what was done (device *working*, last maintenance stamped, can close other open reports on the same device) — or *Close without repair* (no fault / duplicate…). Every step lands in the device log.

## Languages and code
- **HTML / CSS / JavaScript** in `public/` — the pages (no framework). `css/app.css` base styles, `css/lab.css` lab pieces.
- **JavaScript** on the server — a Cloudflare Worker (`src/index.js`): pages, `/api/*`, report photos.
- **SQL** — one SQLite Durable Object (`src/store.js`): users, sessions (PBKDF2-hashed passwords), labs, devices, reports, logs, photos, about page.
- `public/js/i18n.js` — Arabic strings are the keys; the `EN` dictionary translates every string (server errors too).
- `public/js/core.js` helpers · `student.js` student pages · `team.js` team pages · `app.js` router.
- `presentation/` — the project slides (Arabic + English) and the scripts that build them.

## Run / deploy
```
npm install
npx wrangler dev --port 8864          # local copy at http://localhost:8864
npx wrangler secret put RECOVERY_KEY  # once: the code for "Forgot password?"
npx wrangler deploy
```
`school.sh` is a helper for a computer whose default wrangler login is a *different* Cloudflare account: it deploys with a
separately saved login (`~/.wrangler/config/default.toml.school`) and the account ID in an untracked `.school-account` file,
without switching the default login.
